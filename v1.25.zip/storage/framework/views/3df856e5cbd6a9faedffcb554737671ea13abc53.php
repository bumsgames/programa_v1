<div class="hijo contenedor">
	<style>	
	.contenedor:hover .imagen {-webkit-transform:scale(1.1);transform:scale(1.1); transition: all 0.3s ease-in-out;}
	.contenedor {overflow:hidden;}
</style>


<div class="card cartaInicio" style="overflow:hidden">
	
		
		<style>	
		.img-top{
			/*	max-width: 180px;*/
			min-height: 260px;
			max-height: 260px;
		}
	</style>
	<center>
		<div class="" style="background-color: white;">
			<img class="img-top" src="<?php echo e(url('img/'.$articulo->fondo)); ?>" alt="Card image cap">
		</div>
	</center>


	<?php if($articulo->oferta > 0): ?>
	
	<div class="cartaEtiqueta_oferta">
		<img  src="<?php echo e(url('img/oferta.png')); ?>" alt="" class="oferta-img">
	</div>
	<?php endif; ?>

	<!-- <div class="cartaFoto_pequena"> 
			<img class="portada_articulo" src="<?php echo e(url('img/'.$articulo->image)); ?>"> 
		</div>  -->
		<div class="card-body letraNegra">
			<div class="titulo_carta" style="color: red !important; font-size: 14px;">
				<strong><?php echo e($articulo->name); ?></strong>
			</div>
			<strong><p style='font-size: 12px;'><?php echo e($articulo->pertenece_category->category); ?></p></strong>		

			<?php if($articulo->category == 4 || $articulo->category == 6 || $articulo->category == 11 || $articulo->category >= 14): ?>	
			<p style='font-size:12px'>Envios al siguiente dia habil luego del pago.</p>
			<?php else: ?>
			<p style='font-size:12px;'>Peso: <?php echo e($articulo->peso); ?>GB</p>
			<?php endif; ?>

		</div>

		<div class="lightgray" style="background: #F1948A;">
			<div class="row nose">
				<div class="col">
					<button class="btn btn-primary btn-block botonCarta"
					onclick="agregaCarro('<?php echo e($articulo->id); ?>', '<?php echo e($articulo->name); ?>', 
						'<?php echo e($articulo->pertenece_category->category); ?>', 
						<?php echo e($articulo->price_in_dolar); ?>,
						'<?php echo e($articulo->fondo); ?>', <?php echo e($moneda_actual->valor); ?>, '<?php echo e($moneda_actual->sign); ?>');">
						<i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> 
					</button>
				</div>
				<div style='font-size: 11px;' class="col-8 cartaCifra mt-1 mb-1">
					<?php if($articulo->oferta==1): ?> 
					<del> 
						<strong class="precio_rebajado">
							<?php echo e(number_format($articulo->offer_price * $moneda_actual->valor, 2, ',', '.')); ?> <?php echo e($moneda_actual->sign); ?>

						</strong>
					</del> 
					<?php endif; ?>
					&nbsp;<strong> <?php echo e(number_format($articulo->price_in_dolar * $moneda_actual->valor, 2, ',', '.')); ?> <?php echo e($moneda_actual->sign); ?> </strong>
				</div>
			</div>
		</div>
	</div>
</div>