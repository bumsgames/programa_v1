<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> <?php echo e($title); ?></h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<?php if($articles->total() == 0): ?>
					<h6>Mostrando 0 articulos</h6>
				<?php else: ?>
					<h6>Mostrando del <?php echo e(($articles->perPage())*($articles->currentPage()-1)+1); ?> al <?php echo e(($articles->perPage() * $articles->currentPage())-($articles->perPage() - $articles->count())); ?> de <?php echo e($articles->total()); ?> resultados</h6>
					
				<?php endif; ?>
				<div class="row">
					<form action="<?php echo e(url('articulos_bd')); ?>" method="POST" class="form-inline col-12 col-lg-7" target="_blank">
						<?php echo e(csrf_field()); ?>

						<div class="my-1 mr-sm-2">
							<input autocomplete="off" type="text" placeholder="Buscar" class="form-control" name="coincidencia" id="buscador" <?php if(isset($busqueda)): ?> value=<?php echo e($busqueda); ?> <?php endif; ?>>
						</div>
						<button type="submit" class="btn btn-primary mr-sm-2 my-1">
							<i class="fa fa-search" aria-hidden="true"></i> 
							Buscar Coincidencia
						</button>
						<button type="button" class="btn btn-primary my-1 mr-sm-2" data-toggle="collapse" data-target="#filtros"><i class="fa fa-gear"></i>Filtros</button>
						
					</form>
					<form action="<?php echo e(url('articulosAllOrdenados')); ?>" method="POST" class="form-inline col-12 col-lg-5">
						<?php echo e(csrf_field()); ?>

						<div class="my-1 form-group mr-sm-2">
							<label for="sel1">Ordenar por:  </label>
							<select name="parametro" class="form-control" id="order">
								<option value="1">Precio</option>
								<option value="2">Precio Oferta</option>
								<option value="3">Titulo</option>
								<option value="4">Nickname</option>
								<option value="5">Correo</option>
								<option value="6">Fecha de reset</option>
							</select>
						</div>
						<div class="my-1 form-group mr-sm-2">
							<label for="sel1">de:  </label>
							<select name="mayormenor" class="form-control" id="by">
								<option value="1">Mayor a menor</option>
								<option value="2">Menor a mayor</option>
							</select>
						</div>
						<button type="submit" class="btn btn-primary mr-sm-2 my-1">
							<i class="fa fa-search" aria-hidden="true"></i> 
							Ordenar
						</button>
					</form>
				</div>
				<br>
				<form action="<?php echo e(url('aplicar_filtros_multiples')); ?>" method="POST" target="_blank">
				<?php echo e(csrf_field()); ?>


				<div id="filtros" class="collapse">
					<div class="row" style="margin-left:0">
						<div class="form-group col-12">
							<label for="namefilt"> Filtrar por nombre</label>
							<input autocomplete="off" class="form-control" type="text" name="namefilt" placeholder="Filtrar por nombre" <?php if(isset($busqueda)): ?> value=<?php echo e($busqueda); ?> <?php endif; ?>>
						</div>
						<div class="form-group col-12 col-lg-3">
							<label for="selcat">Filtrar por categoria</label>
							<select name="selcat" class="form-control" id="selcat">
								<option value='0'>No filtrar</option>
								<?php $cont=0?>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($categoria->id); ?>" <?php if(isset($parametros[0])): ?><?php if($parametros[0] == $categoria->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($categoria->category); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>	
						<div  class="form-group col-12 col-lg-3">
							<label for="seldu">Filtrar por Dueño</label>
							<select name="seldu" class="form-control custom-select" id="seldu">
								<option value="0">No filtrar</option>
								<?php $cont=0?>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($usuario->id); ?>" <?php if(isset($parametros[8])): ?><?php if($parametros[8] == $usuario->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($usuario->name); ?> <?php echo e($usuario->lastname); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div  class="form-group col-12 col-lg-3">
							<label for="correofiltro">Filtrar por Correo</label>
							<input <?php if(isset($parametros[1])): ?> value="<?php echo e($parametros[1]); ?>" <?php endif; ?> autocomplete="off" type="text" placeholder="Buscar correo" class="form-control" name="filtrocorreo" id="correofiltro">
						</div>
						<div class="form-group col-12 col-lg-3">
							<label for="seldu">Filtrar por disponibilidad</label>
							<div class="form-control">
								<div class="custom-control custom-radio custom-control-inline">
									<input type="radio" class="custom-control-input" id="disponible" name="disponible" value="1" <?php if(isset($parametros[2])): ?><?php if($parametros[2] == 1): ?> checked <?php endif; ?> <?php endif; ?>>
									<label class="custom-control-label" for="disponible">Disponible</label>
								</div>
								<div class="custom-control custom-radio custom-control-inline">
									<input type="radio" class="custom-control-input" id="nodisponible" name="disponible" value="2"  <?php if(isset($parametros[2])): ?><?php if($parametros[2] == 2): ?> checked <?php endif; ?> <?php endif; ?>>
									<label class="custom-control-label" for="nodisponible">No disponible</label>
								</div> 
								<div class="custom-control custom-control-inline" style="margin-right:0">
									<button id="uncheck" class="btn btn-primary btn-sm" type="button">Resetear</button>
								</div>
							</div>
						</div>
						
					</div>
					<div class="row" style="margin-left:0">
						<div class="form-group col-12 col-lg-3">
							<label for="creatorfilter">Filtrar por creador</label>
							<select name="creatorfilter" class="form-control" id="creatorfilter">
								<option value="0">No filtrar</option>
								<?php $cont=0?>
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($usuario->id); ?>" <?php if(isset($parametros[3])): ?><?php if($parametros[3] == $usuario->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($usuario->name); ?> <?php echo e($usuario->lastname); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>	


						<div  class="form-group col-12 col-lg-3">
							<label for="nickfil">Filtrar por Nickname</label>
							<input autocomplete="off" type="text" <?php if(isset($parametros[4])): ?> value="<?php echo e($parametros[4]); ?>"  <?php endif; ?> placeholder="Buscar Nickname" class="form-control" name="nickfil" id="nickfil">
						</div>

						<div class="form-group col-12 col-lg-3">
							<label for="precio">Filtrar por Precio</label>
							<div >
								<label for="preciorange">Precio Minimo: <span id="precioranget"></span > $</label>
  								<input <?php if(isset($parametros[5])): ?> value="<?php echo e($parametros[5]); ?>" <?php else: ?> value="0" <?php endif; ?>  type="range" class="custom-range" id="preciorange" name="precio">
							</div>
							<div>
								<label  for="ofertarange">Precio Subrayado Minimo: <span id="ofertaranget"></span> $</label>
  								<input <?php if(isset($parametros[6])): ?> value="<?php echo e($parametros[6]); ?>" <?php else: ?> value="0" <?php endif; ?> type="range" class="custom-range" id="ofertarange" name="oferta">
							</div>
						</div>
						<div class="form-group col-12 col-lg-3">
							<label for="peso">Filtrar por Peso Minimo</label>
							<div class="form-control">
								<label for="pesorange">Peso: <span id="pesoranget"></span > GB</label>
  								<input <?php if(isset($parametros[7])): ?> value="<?php echo e($parametros[7]); ?>" <?php else: ?> value="0" <?php endif; ?> type="range" class="custom-range" id="pesorange" name="peso">
							</div>
						</div>
						
					</div>	
								
					<button type="submit" class="btn btn-primary my-1 mr-sm-2">Filtrado multiple</button>

				</div>
				</form>
				<br>	
				
					<?php if($articles->hasPages()): ?>
				<ul class="pagination justify-content-center">
					<?php if($articles->onFirstPage()): ?>
						<li class="page-item disabled"><span class="page-link"><</span></li>
					<?php else: ?>
						<li class="page-item"><a class="page-link" href="<?php echo e($articles->previousPageUrl()); ?>" rel="prev"><</a></li>
					<?php endif; ?>

					<?php if($articles->currentPage() > 3): ?>
						<li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($articles->url(1)); ?>">1</a></li>
					<?php endif; ?>
					<?php if($articles->currentPage() > 4): ?>
						<li class="page-item"><span class="page-link">...</span></li>
					<?php endif; ?>
					<?php $__currentLoopData = range(1, $articles->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($i >= $articles->currentPage() - 2 && $i <= $articles->currentPage() + 2): ?>
							<?php if($i == $articles->currentPage()): ?>
								<li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
							<?php else: ?>
								<li class="page-item"><a class="page-link" href="<?php echo e($articles->url($i)); ?>"><?php echo e($i); ?></a></li>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php if($articles->currentPage() < $articles->lastPage() - 3): ?>
						<li class="page-item"><span class="page-link">...</span></li>
					<?php endif; ?>
					<?php if($articles->currentPage() < $articles->lastPage() - 2): ?>
						<li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($articles->url($articles->lastPage())); ?>"><?php echo e($articles->lastPage()); ?></a></li>
					<?php endif; ?>

					<?php if($articles->hasMorePages()): ?>
						<li class="page-item"><a class="page-link" href="<?php echo e($articles->nextPageUrl()); ?>" rel="next">></a></li>
					<?php else: ?>
						<li class="page-item disabled"><span class="page-link">></span></li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
			
				<br>
				<div class="table-responsive">
				
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Informacion</th>
								<th scope="col">Dueño</th>
								<?php if(Auth::user()->level >= 7): ?>
								<th scope="col">Correo y Clave</th>

								<?php else: ?>
								<th></th>
								<?php endif; ?>
								<th scope="col">Cantidad</th>
								<th scope="col">Botones</th>
							</tr>
						</thead>
						<?php $i=1; ?>
						<tbody>
							<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr class="prod">
								<th scope="row">
									<?php echo $i++; ?>
								</th>
								<td>
									<div class="nombreafiltrar"><?php echo e($article->name); ?></div> (ID: <?php echo e($article->id); ?>)
									<br>	
									<br>	
									<strong>
										Categoria: 
									</strong>
									<br>	
									<div class="catefiltrar"><?php echo e($article->pertenece_category->category); ?></div>
									<br>
									<br>
									<strong>
										Agregado por: 
									</strong>
									<br>	
									<div class="crefiltrar"><?php echo e($article->pertenece_id_creator->name); ?> <?php echo e($article->pertenece_id_creator->lastname); ?></div>
									<br>
									<br>
									<strong>
										Nota: 
									</strong>
									<?php echo $article->note; ?> 
									<br>
									<br>
									<?php
										$compronumber=$article->clientes_del_articulo->count();
									?>
									<?php if($article->clientes_del_articulo->count() > 0): ?>
									<strong>Vendedor por cliente: </strong>
									<br>
									<?php $j = 1; ?>
							
									<?php $__currentLoopData = $article->ventas_del_articulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php echo $j++; ?>) <?php echo e($ventas->user->name); ?> <?php echo e($ventas->user->lastname); ?> <br>	
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<br>
									<br>	
									<?php endif; ?>
								</td>
								<td style="width: 20%;">
									<?php $__currentLoopData = $article->duennos->sortBy('porcentaje'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duenno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<strong>
										Dueño:
									</strong>
									<br>
									<div class="dufiltrar"><?php echo e($duenno->name); ?> <?php echo e($duenno->lastname); ?></div>
									<?php if($duenno->pivot->porcentaje != 100): ?>
									<br>
									<strong>
										Acciones:
									</strong>
									<br>
									<?php echo e($duenno->pivot->porcentaje); ?> %

									<?php endif; ?>
									<br>	
									<br>	
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
									<?php if(Auth::user()->level >= 7): ?>
									<br>
									<br>
									<br>
									<br>
									<br>
									<br>
									<br>
									<br>
									<br>
									<?php if($article->clientes_del_articulo->count() > 0): ?>
									<strong>Clientes dueños del articulo: </strong>
									<br>
									<?php $j = 1; ?>
									<?php $__currentLoopData = $article->clientes_del_articulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php echo $j++; ?>) <?php echo e($cliente->name); ?> <?php echo e($cliente->lastname); ?> <br>	
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<br>
									<br>	
									<?php endif; ?>
									<?php endif; ?>

								</td>
								<td>
									<?php if(Auth::user()->level >= 7): ?>
									<strong>
										Correo: 
									</strong>
									<br>	
									<div class="correofiltrar"><?php echo e($article->email); ?> </div>
									<br>
									<br>
									<strong>
										Password: 
									</strong>
									<br>	
									<?php echo e($article->password); ?>

									<br>
									<br>
									<strong>
										Nickname: 
									</strong>
									<br>	
									<div class="nickfiltrar"><?php echo e($article->nickname); ?></div> 
									<br>
									<br>
									<?php if(!(empty($article->reset_button))): ?>
									<strong>	
										Fecha de reseteo: 
									</strong>
									<?php echo e(date('d-m-Y', strtotime($article->reset_button))); ?> 
									<?php endif; ?>
									<br>
									<br>
									<?php if($article->clientes_del_articulo->count() > 0): ?>
									<strong>Numero de contacto de comprador: </strong>
									<br>
									<?php $j = 1; ?>
									<?php $__currentLoopData = $article->clientes_del_articulo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php echo $j++; ?>) <?php echo e($cliente->num_contact); ?> <br>	
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<br>
									<br>	
									<?php endif; ?>
									<?php endif; ?> 	
								</td>
								<td>	
									Cantidad: <?php echo e($article->quantity); ?>

									
									<br>	
									<br>
									<strong>Precio: </strong>
									<br>
									<span class="preciofil"><?php echo e($article->price_in_dolar); ?></span> $
									<br>	
									<br>
									<strong>Precio subrayado: </strong>
									<br>
									<span class="ofertafil"><?php echo e($article->offer_price); ?></span> $
									<br>	
									<br>	
									<?php if(!in_array($article->category, array(4,6,11,14,15))): ?>
									<strong>Peso del juego: </strong>
									<br>
									<span class="pesofil"><?php echo e($article->peso); ?></span> GB
									<br>	
									<br>
									<?php endif; ?>
								</td>
								<td>
									<?php if(Auth::user()->level >= 7): ?>
									<div class="btn-group" role="group" aria-label="Basic example">
										<button type="button" 
										class="btn btn-secondary" 
										data-toggle="modal" data-target=".bd-example-modal-lg"	
										value="<?php echo e($article->id); ?> "
										Onclick='vender_articulo(<?php echo e($article->id); ?>,"<?php echo e($article->name); ?>", "<?php echo e($article->email); ?>", "<?php echo e($article->password); ?>","<?php echo e($article->pertenece_category->category); ?>",<?php echo e($article->category); ?>);'>
										Vender
									</button>
									<?php endif; ?>

									<form action="/buscar_articulo" method="post" target="_blank">
										<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">
										<input autocomplete="off" type="text" hidden="" value="<?php echo e($article->id); ?>" name="id_art">
										<button type="submit" class="btn btn-secondary" data-toggle="modal" data-target="" value="" Onclick="">Modificar</button>
									</form>
									
									<button type="submit" class="btn btn-secondary" data-toggle="modal" data-target=".bd-example-modal-lg3" Onclick="mandaridM(<?php echo e($article->id); ?>)">Eliminar</button>

									
									
								</div>
								<br>
								<br>
								
								<button type="button" 
									class="btn btn-secondary" 
									data-toggle="modal" 
									data-target=".modal_rapido" 
									value="<?php echo e($article->id); ?>" 
									
									Onclick='modicacion_rapida(
										<?php echo e($article->id); ?>,
										"<?php echo e($article->name); ?>",
										"<?php echo e($article->pertenece_category->category); ?>",
										<?php echo e($article->quantity); ?>,
										"<?php echo e($article->note); ?>",
										"<?php echo e($article->reset_button); ?>")'>
									Modificacion Rapida
								</button>
								<br>
								<br>
								
								<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".modal_cliente" onclick='mostrar_articulo_cliente(<?php echo e($article->id); ?>)'>Parte cliente</button>

							</div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
			</tbody>
		</table>
	</div>
	
	<?php if($articles->hasPages()): ?>
				<ul class="pagination justify-content-center">
					<?php if($articles->onFirstPage()): ?>
						<li class="page-item disabled"><span class="page-link"><</span></li>
					<?php else: ?>
						<li class="page-item"><a class="page-link" href="<?php echo e($articles->previousPageUrl()); ?>" rel="prev"><</a></li>
					<?php endif; ?>

					<?php if($articles->currentPage() > 3): ?>
						<li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($articles->url(1)); ?>">1</a></li>
					<?php endif; ?>
					<?php if($articles->currentPage() > 4): ?>
						<li class="page-item"><span class="page-link">...</span></li>
					<?php endif; ?>
					<?php $__currentLoopData = range(1, $articles->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($i >= $articles->currentPage() - 2 && $i <= $articles->currentPage() + 2): ?>
							<?php if($i == $articles->currentPage()): ?>
								<li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
							<?php else: ?>
								<li class="page-item"><a class="page-link" href="<?php echo e($articles->url($i)); ?>"><?php echo e($i); ?></a></li>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php if($articles->currentPage() < $articles->lastPage() - 3): ?>
						<li class="page-item"><span class="page-link">...</span></li>
					<?php endif; ?>
					<?php if($articles->currentPage() < $articles->lastPage() - 2): ?>
						<li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($articles->url($articles->lastPage())); ?>"><?php echo e($articles->lastPage()); ?></a></li>
					<?php endif; ?>

					<?php if($articles->hasMorePages()): ?>
						<li class="page-item"><a class="page-link" href="<?php echo e($articles->nextPageUrl()); ?>" rel="next">></a></li>
					<?php else: ?>
						<li class="page-item disabled"><span class="page-link">></span></li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
			

</div>

</div>
</div>

</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$('#uncheck').click(function(){
	$('input[name="disponible"]:checked').prop('checked', false);
});
</script>
<?php echo $__env->make('modal.venta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.modificacionRapida', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('modal.eliminar_articulo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.parte_cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>