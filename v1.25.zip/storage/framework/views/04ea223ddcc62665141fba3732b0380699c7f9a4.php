<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> Generar reporte</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">

				<div class="tile-body"> </div>
				<form class="row" action="guardar_reporte" method="post">
					<?php echo e(csrf_field()); ?>

					
					<div class="form-group col-md-2">
						<label for=""><strong>Tipo de reporte</strong></label>
						<select class="form-control form-control-sm		" name="type_reporte" id="">
							<option value="Idea">	Idea</option>
							<option value="Pregunta">Pregunta</option>
							<option value="Reporte">Reporte</option>
						</select>
					</div>
					<div class="form-group col-md-3">
						<label class="control-label"><strong>	Titulo</strong></label>
						<input autocomplete="off" class="form-control form-control-sm" name="titulo_reporte" type="text">
					</div>
					<div class="form-group col-md-4">
						<label class="control-label"><strong>	Descripcion</strong></label>
						<textarea autocomplete="off" class="form-control" name="descripcion_reporte" id="" cols="30" rows="2">
						</textarea>
					</div>
					<div class="form-group col-md-3">
						<br>	
						<button class="btn btn-primary btn-block">Generar reporte</button>
					</div>

					
					
				</form>
				<hr>	
				<div class="row">
					<?php $__currentLoopData = $reportes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-6">
						<div class="tile">
							<p><?php echo e($reporte->created_at->diffForHumans()); ?></p>
							<?php if(isset( $reporte->creadorF->name)): ?>
							<p>Por: <?php echo e($reporte->creadorF->name); ?> <?php echo e($reporte->creadorF->lastname); ?></p>
							<?php endif; ?>
							
							<h3 class="tile-title"><?php echo e($reporte->titulo_reporte); ?></h3>
							
							<div class="tile-body"><?php echo e($reporte->descripcion_reporte); ?></div>
							<?php if(auth()->user()->level >= 7): ?>
							<div class="tile-footer"> <button class="btn btn-primary" data-toggle="modal" data-target=".eliminar-report" Onclick="mandaridM(<?php echo e($reporte->id); ?>);">
								<i class="fa fa-fw fa-lg fa-check-circle"></i>
							Solucionado</button></div>
							<?php endif; ?>


							<p style="float: right;">
								<strong>Tipo: </strong>
								<?php echo e($reporte->type_reporte); ?>

							</p>
						</div>
					</div>
					<br>	
					<br>	
					<br>	
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					
				</div>
				<br>
			</div>
		</div>
		<?php echo $__env->make('modal.eliminar-reporte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</main>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>