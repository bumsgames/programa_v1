<form action="<?php echo e(route("filtrar_ventas")); ?>" method="post">
	Solo sirve para buscar ventas y el parametro es por la persona que hizo la venta.
	<br>
	<br>
	<?php echo e(csrf_field()); ?>

	<div class="form-row align-items-center">
		<div class="col-md-4">
			<label for="validationCustomUsername">Fecha de comienzo</label>
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text" id="inputGroupPrepend">Comienzo: </span>
				</div>
				<input <?php if(isset($fecha_inicio)): ?> value="<?php echo e($fecha_inicio); ?>" <?php endif; ?> type="date" class="form-control" name="fecha_inicio" id="validationCustomUsername" placeholder="Username" aria-describedby="inputGroupPrepend" required>
				<div class="invalid-feedback">
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<label for="validationCustomUsername">Fecha final</label>
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text" id="inputGroupPrepend">Final: </span>
				</div>
				<input <?php if(isset($fecha_final)): ?> value="<?php echo e($fecha_final); ?>" <?php endif; ?> type="date" class="form-control" id="validationCustomUsername" name="fecha_final" placeholder="Username" aria-describedby="inputGroupPrepend" required>
				<div class="invalid-feedback">

				</div>
			</div>
		</div>
		<div class="col-md-4">
			<label for="validationCustomUsername">Usuario</label>
			<select class="form-control" name="id_usuario" id="">
				<option <?php if(isset($id_usuario)): ?> <?php echo e($id_usuario==0?"selected":""); ?> <?php endif; ?> value="0">Todos los usuarios</option>
				<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option <?php if(isset($id_usuario)): ?> <?php echo e($id_usuario==$usuario->id?"selected":""); ?> <?php endif; ?> value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->name); ?> <?php echo e($usuario->lastname); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>

		</div>
	</div>	
	<br>	
	<center>
		<button class="btn btn-primary">Buscar</button>
	</center>
	<br>	

</form>