<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Prueba</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"/>
</head>
<body>
	<div class="container">
		<h1>LISTA DE ARTICULOS DISPONIBLES DE: <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></h1>
		<?php $i = 1; ?>
		<?php $categoria = ''; ?>
		<div class="row">
			<div class="col">
				<?php $cuenta = 0; 
					$inversion = 0;
				?>
				<?php $__currentLoopData = $articles_mios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $articles_mios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(($articulo->id != $articulo2->id) && ($articulo->name == $articulo2->name) && ($articulo->porcentaje == $articulo2->porcentaje) && ($articulo->category == $articulo2->category)): ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $articles_mios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($articulo->pertenece_category->category != $categoria): ?>
				<?php $categoria = $articulo->pertenece_category->category; ?>
				<?php $i = 1; ?>
				<br>
				<br>
				<h4><strong><?php echo e($categoria); ?></strong></h4>
				<br>
				<br>
				<?php endif; ?>

				<strong><?php echo $i++; ?></strong>. <?php echo e($articulo->name); ?>. <strong>Cantidad:</strong> <?php echo e($articulo->quantity); ?>. <strong>Acción:</strong> <?php echo e($articulo->porcentaje); ?>%,
				<strong> <?php echo e(number_format((($articulo->price_in_dolar)*$articulo->quantity*$articulo->porcentaje/100 )	, 2, ',', '.')); ?> $</strong> - Precio unitario: <?php echo e(number_format(($articulo->price_in_dolar)	, 2, ',', '.')); ?> $
				<br><br>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $inversion_cat = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
					$cuenta_cat = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
				?> 
				<?php $__currentLoopData = $articles_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $cuenta += $aprice->price_in_dolar*$aprice->quantity*$aprice->porcentaje/100; 
					$cuenta_cat[$aprice->category] += $aprice->price_in_dolar*$aprice->quantity*$aprice->porcentaje/100;
				?>	  
				<?php $inversion += $aprice->costo*$aprice->quantity;
					$inversion_cat[$aprice->category] +=  $aprice->costo*$aprice->quantity;
				?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
 
		</div>
		<br>
		<br>
		<h3>Articulos disponibles: <?php echo e($articles_price->count()); ?></h3>
		<h3>Valor en Articulos de <?php echo e($user->name); ?> <?php echo e($user->lastname); ?>: <?php echo e(number_format((($cuenta) )	, 2, ',', '.')); ?> $	</h3>
		<h3>Inversión total: <?php echo e(number_format((($inversion) )	, 2, ',', '.')); ?> $</h3>
		<h3>Valor por categoria:</h3>
		<br>
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h4 style="font-weight:normal"><?php echo e($category->category); ?>: <strong><?php echo e(number_format((($cuenta_cat[$category->id]) )	, 2, ',', '.')); ?> $</strong></h4>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<br>
		<h3>Inversión por categoria:</h3>
		<br>
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<h4 style="font-weight:normal"><?php echo e($category->category); ?>: <strong><?php echo e(number_format((($inversion_cat[$category->id]) )	, 2, ',', '.')); ?> $</strong></h4>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

</body>
</html>