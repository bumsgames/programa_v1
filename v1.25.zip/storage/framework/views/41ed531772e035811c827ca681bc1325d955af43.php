<?php $__env->startSection('ultimos-vendidos'); ?>
<style>
	.btn-categorias{
		margin: 20px;
		padding: 10px !important;
	}
	</style>
	<style>
	.vendido_img{
		border-radius: 250px;
		width: 150px;
		height: 150px;
	}
	</style>
	<div class="container-fluid">
		<div class="row justify-content-center ultimo-vendido-banner">
			<div class="col-12 col-xl-2 text-center">
				<br>
				<img class="vendido_img" src="img/maxresdefault.jpg" alt="">
			</div>
			<div style="border-left-style: solid; margin: 0 40px;"></div>
			<div class="col-12 col-xl-9">
				<div class="row">
					<div class="col-12">
						<h3 class="ultimo-vendido-title" style="width:100%">Ultimos articulos vendidos</h3>
					</div>
				</div>
				<div class="row">
					<?php $__currentLoopData = $ultimos_vendidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-12 col-xl-4">
						<br>
						<div class="ultimo-vendido-content">
							<div class="ultimo-vendido-c-img text-center" style="overflow:hidden;max-width:50%">
								<img src="img/<?php echo e($uv->articulo->fondo); ?>" height="130" style="width:auto" alt="">
							</div>
							<div class="ultimo-vendido-c-text">
								<?php echo e($uv->articulo->name); ?>

								<br>
								<strong><?php echo e($uv->articulo->pertenece_category->category); ?></strong>
								<br>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div>
				
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<br>
<style>
.btn-categorias{
	margin: 20px;
	padding: 10px !important;
}
.fondoBlanco{
	color: black !important;
	background: white !important;
}
</style>
<div class="container">
	<div class="fondotituloEscrito">
		<h2 class="titulobumsEscrito">Ayuda</h2>
	</div>
	<div class="tile fondoBlanco" style="padding-left:0">

		
		<br>
		<style>	
.list-group .active{
	background: #ff0005;
	border: none !important;
	opacity: 0.8 !important;
}

.hr_negro{
    border: 1px black solid;
}
	</style>
		<div class="row">
			<div class="col">
				<div class="row">
					<div class="col-12 col-lg-4">
						<div class="list-group" id="list-tab" role="tablist">
							<a class="list-group-item list-group-item-action ayuda-item active" id="list-digital-list" data-toggle="list" href="#list-digital" role="tab" aria-controls="digital">¿Que es un juego digital?</a>
							<a class="list-group-item list-group-item-action ayuda-item " id="list-principal-list" data-toggle="list" href="#list-principal" role="tab" aria-controls="principal">¿Que es un Juego Digital Primario, Secundario y Codigo?</a>
							<a class="list-group-item list-group-item-action ayuda-item " id="cambio-list" data-toggle="list" href="#cambio" role="tab" aria-controls="norma">¿Cómo funciona nuestro sistema de cambio?</a>
							<a class="list-group-item list-group-item-action ayuda-item " id="beneficios-list" data-toggle="list" href="#beneficios" role="tab" aria-controls="norma">Beneficios de ser un usuario registrado</a>
							<a class="list-group-item list-group-item-action ayuda-item " id="list-norma-list" data-toggle="list" href="#list-norma" role="tab" aria-controls="norma">Normas del sitio</a>
							<a class="list-group-item list-group-item-action ayuda-item " id="tutorial-list" data-toggle="list" href="#tutorial" role="tab" aria-controls="norma">Tutorial para descargas</a>
						</div>
					</div>
					<div class="col-12 col-lg-8">
						<div class="tab-content letraNegra ayudabody" id="nav-tabContent">
							<div class="tab-pane fade show active" id="list-digital" role="tabpanel" aria-labelledby="list-digital-list">
							    <center class="fondo-titulo-ayuda">
							        <h1 class="titulo-ayuda">¿Que es un juego digital?</h1>
								 </center>
								<br>
							    <br>
							   	<p> 
									Es un juego completo al igual que un juego en formato físico, la diferencia es que un juego digital está contenido 
									en una cuenta desde la cual se podrá comenzar la descarga del mismo, el juego quedará en el disco duro de la consola, 
									estos juegos son 100% originales, la consola no debe estar chipeada para poder descargar los juegos digitales. Ofrecemos 
									garantía de la compra permanente pero para ello se debe guardar nuestras normativas obligatoriamente, en caso de faltar 
									a nuestras políticas el comprador irrumpe en la garantía.
								</p>
								<br>
								<br>
							    <center class="mensaje-importante">Los juegos descargados mediante cuentas son solo para uno y solo una Consola</center>
							    <br>
							    <br> 
							</div>
							<div class="tab-pane fade" id="list-principal" role="tabpanel" aria-labelledby="list-principal-list">   
									<center class="fondo-titulo-ayuda">
							            <h1 class="titulo-ayuda">¿Que es un Juego Digital Primario, Secundario y Codigo?</h1>
							        </center>
									<br>
									<br>
							        <center>
							            <h3 class="titulo-ayuda-MINI">
							                Juego Digital Primario
							            </h3>
							        </center>
							        <br>
									<br>
									<ul>
							        	<li>Se comienza la descarga del juego mediante una cuenta alterna.</li>
							        	<li>Podrás jugar desde tu usuario personal u otro de tu preferencia.</li>
							        	<li>No necesitas internet para jugar una vez descargado.</li>
										<li>Los trofeos son agregados a tu perfil.</li>
										<li>Totalmente igual a un juego en formato físico.</li>
									</ul>
							        <br>
							        <br>
							         <center>
									 <h3 class="titulo-ayuda-MINI">
							            Juego Digital Secundario
							        </h3>
							        </center>
							        <br>
									<br>
									<ul>
							        	<li>Se comienza la descarga del juego mediante una cuenta alterna.</li>
							        	<li>Se juega mediante el usuario desde donde se realizó la descarga.</li>
							        	<li>En algunos casos en PS4 podrás jugar desde tu usuario y en Xbox One podrás jugar siempre desde cualquier usuario.</li>
							        	<li>Necesitas internet obligatoriamente para jugar.</li>
										<li>Totalmente igual a un juego en formato físico.</li>
									</ul>
							        <br>
									<br>
							        <center>
									<h3 class="titulo-ayuda-MINI">
										Juego digital por código
									</h3>
							        </center>
									<br>
									<br>
									<p>
										Es un juego completo al igual que un juego en formato físico, los juegos por códigos son canjeados en la 
										cuenta del comprador, por lo cual una vez comprados los juegos quedan vinculados para siempre a dicha cuenta.
									</p>
							        <br>
							        <br>
							        <center class="mensaje-importante">Los juegos descargados mediante cuentas son solo para uno y solo una Consola</center>
							        <br>
							        <br>
							        
									</div>
							<div class="tab-pane fade" id="cambio" role="tabpanel" aria-labelledby="cambio-list">   
								<center class="fondo-titulo-ayuda">
									<h1 class="titulo-ayuda">
										¿Cómo funciona nuestro sistema de cambio?
									</h1>
							        </center>   
								 <br>
								 <br>
									<br>
								<ul>
							        <li>
										Puedes utilizar tus juegos digitales comprados a nosotros, como parte de pago para adquirir cualquier otro 
										artículo de nuestro stock.
									</li>
									<li>
										Para conocer el porcentaje al cual se le recibirá el juego ofrecido como parte de pago, debe comunicarse con un 
										agente Bumsgames, este porcentaje se calcula dependiendo el año del juego, la demanda y otros factores.
									</li>
									<li>
										Tus juegos físicos también puedes utilizarlos como parte de pago para adquirir cualquier juego de nuestro 
										stock, en caso de no estar en la cuidad no asumimos el precio de envío, correrá de parte de la persona interesada 
										cancelar el envió del juego que desee ofrecer como parte de pago.
									</li>
								</ul>
								<br>
							    <br>
							</div>
							<div class="tab-pane fade" id="beneficios" role="tabpanel" aria-labelledby="beneficios-list">   
								<center class="fondo-titulo-ayuda">
									<h1 class="titulo-ayuda">
										Beneficios de ser un usuario registrado
									</h1>
								</center>   
								<br>
								<br>
								<br>
								<p>
									Al realizar tu primera compra en el sitio, un agente de BumsGames te registrara en el sistema.
									<br><br>	
									Al estar registrado en el sistema podras revisar los productos que te pertenecen asi como las compras que has realizado en el pasado.
									<br><br>
									En adición a esto. Podras tener un control de los productos que son tuyos y aquellos que has cambiado.
									<br>
									Podras ver el correo electrónico de las cuentas digitales que te pertenecen y en el caso de las cuentas secundarias, podras ver su contraseña en cualquier momento
								</p>	
								<br>
								<br>
							</div>
							<div class="tab-pane fade" id="list-norma" role="tabpanel" aria-labelledby="list-norma-list">   
								<center class="fondo-titulo-ayuda">
									<h1 class="titulo-ayuda">
										Normas del sitio
									</h1>
								</center>   
								<br>
								<br>
								<br>
								<ul>
									<li><h5>Los juegos descargados mediante cuentas son válidos solo para una Consola</h5></li>
									<li><h5>El cliente por ninguna razón debe modificar datos de la cuenta, si tiene algún problema con la cuenta comprada debe contactar directamente a su vendedor.</h5></li>
									<li><h5>Debe mantenerse activado en el tipo de cuenta que adquirió (Primario o Secundario).</h5></li>
									<li><h5>Las cuentas son intransferible, en caso de prestar su cuenta y le sea quitado el cupo por un tercero, pierde totalmente la garantía de su compra.</h5></li>
									<li><h5>Al incumplir las normativas hay sanciones como resultados</h5></li>
								</ul>
								<br>
								<br>
								<center class="mensaje-importante">Los juegos descargados mediante cuentas son solo para uno y solo una Consola</center>
								<br>
								<br>
							</div>
							<div class="tab-pane fade" id="tutorial" role="tabpanel" aria-labelledby="tutorial-list">   
								<center class="fondo-titulo-ayuda">
									<h1 class="titulo-ayuda">
										Tutorial para descargas
									</h1>
								</center>   
								<br>
								<br>
								<center>
								<h3 class="titulo-ayuda-MINI">
									Descarga PlayStation 4 primario:
								</h3>
								</center>
								<br>
								<br>
								<p>
									<strong>VIDEOTUTORIAL PARA DESCARGAR:</strong> Al ingresar al siguiente link -> <a href="https://www.youtube.com/watch?v=fzHBj8vPZ3s&t=36s">https://www.youtube.com/watch?v=fzHBj8vPZ3s&t=36s</a> 
									Puedes observar los pasos necesarios para comenzar con la descarga de tu juego versión primaria en menos de 3 
									minutos.
								</p>
								<br>
								<br>
								<center>
								<h3 class="titulo-ayuda-MINI">
									Descargar PlayStation 4 Secundario:
								</h3>
								</center>
								<br>
								<br>
								<p>
									<strong>VIDEOTUTORIAL PARA DESCARGAR:</strong> <a href="https://www.youtube.com/watch?v=5vXs4Gnxxi0&t=12s">https://www.youtube.com/watch?v=5vXs4Gnxxi0&t=12s</a> 
									<br>
									<strong>VIDEOTUTORIAL para jugar:</strong> <a href="https://www.youtube.com/watch?v=lD2_neiQM0c">https://www.youtube.com/watch?v=lD2_neiQM0c</a>
									<br>
									<strong>VIDEOTUTORIAL fallo en bloqueo de usuario secundario (muy poco frecuente):</strong> <a href="https://www.youtube.com/watch?v=2RcHgtIshzQ">https://www.youtube.com/watch?v=2RcHgtIshzQ</a>
									<br>
									<strong>VIDEOTUTORIAL para jugar desde tu usuario:</strong> <a href="https://www.youtube.com/watch?v=X0Ha1McuIto">https://www.youtube.com/watch?v=X0Ha1McuIto</a>	
								</p>
								<br>
								<br>
								<center>
								<h3 class="titulo-ayuda-MINI">
									Descargar PlayStation 3:
								</h3>
								</center>
								<br>
								<br>
								<p>
									<strong>VIDEOTUTORIAL PARA DESCARGAR:</strong> <a href="https://www.youtube.com/watch?v=YZzDS5CJJ4s"> https://www.youtube.com/watch?v=YZzDS5CJJ4s</a>
								</p>
								<br>
								<br>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-lg-2">
				
				
			</div>
			
		</div>
		<br>
		<br>
		<br>
		<br>
	</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillaWeb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>