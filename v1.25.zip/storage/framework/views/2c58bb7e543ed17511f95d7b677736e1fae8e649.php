<?php $__env->startSection('content'); ?>

<div id="bannertop" class="carousel slide" data-ride="carousel" data-interval="5000">
	<div class="carousel-inner">
		<div class="carousel-item active">
			<img class="d-block w-100" src="img/family.jpg" alt="First slide">
		</div>
		<div class="carousel-item">
			<img class="d-block w-100" src="img/gamepad.jpg" alt="Second slide">
		</div>
		<!-- <?php  $count=0;  ?>
				<?php $__currentLoopData = $portal1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php  $count++; ?>
				<div class="carousel-item <?php if($count==1) echo 'active';?>">
					<img style="width: 100%;height: 180px;" class="" src="img/<?php echo e($portal->imagen); ?>" alt="First slide">
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->

			</div>
		</div>

		<img class="badred" src="img/badred.jpg" alt="" height="170" width="2024">


		<div class="redbannersocial">	
			<center>
				<a href="https://www.facebook.com/bumsgamesoficial" target="_blank" title="Vista nuestro facebook, que esperas?"><img src="img/logo-f.png" class="abc" alt=""></a>
				<a href="https://www.instagram.com/bumsgames/" target="_blank" style="margin-left: 140px; border: none;" href="www.google.co.ve" title="Unete a nuestra comunidad en Instagram, tenemos muchas sorpresas"><img class="abc" src="img/logo-i.png" alt=""></a>
				<a href="https://perfil.mercadolibre.com.ve/BUMSGAMES_OFICIAL" target="_blank"  style="margin-left: 140px; border: none;" title="Mira nuestra reputacion en MercadoLibre, somos MercadoLideres"><img class="abc2" src="img/logo-m.png" alt=""></a>
			</center>
		</div>

		<?php $__env->stopSection(); ?>


		<?php $__env->startSection('comment'); ?>
		<!-- container -->
		<!-- style="background:rgba(0,0,0,0.5)" -->
		<div class="patron"> 
<!-- <div class="fondotitulo"><h2 class="titulobums">Bienvenido amig@</h2></div>
</div> -->
<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">

<div class="container maincont">
	<div class="row">
		<div class="col-12 col-lg-5 ">
			<script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.4.0/jquery.marquee.min.js'></script>
			<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" style="padding: 10px">
				<div class="carousel-inner">
					<?php  $count=0;  ?>
					<?php $__currentLoopData = $portal3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php  $count++; ?>
					<div class="carousel-item <?php if($count==1) echo 'active';?>">
						<img class="d-block w-100" src="img/<?php echo e($portal->imagen); ?>" alt="First slide" height="120px">
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
			<div class="colorBackground_Titulo">	

				<h2 class="colortitulo" style="margin-left: 10px; margin-top: 10px; margin-bottom: 10px;"><i class="fas fa-newspaper"></i> ARTICULOS RECIENTES</h2>
			</div>
			<hr>
			<style>
			.marquee_articulos {
				width: 100%;
				overflow: hidden;
				background: rgba(40, 40, 40, 0.95) ;
			}

			.marquee {
				width: 100%;
				height: 95%;
				max-height:480px;
				min-height:480px;
				overflow: hidden;
				border: none;
				background: none;
			}
		</style>
		<div class='marquee_articulos'>
			<div class="padre">
				<?php $count=0?>
				<?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $count++?>
				<?php echo $__env->make('webuser.misc.carta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" style="padding: 10px">
			<div class="carousel-inner">
				<?php  $count=0;  ?>
				<?php $__currentLoopData = $portal3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php  $count++; ?>
				<div class="carousel-item <?php if($count==1) echo 'active';?>">
					<img class="d-block w-100" src="img/<?php echo e($portal->imagen); ?>" alt="First slide" height="120px">
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>

		<script>
			$('.marquee_articulos').marquee({
//speed in milliseconds of the marquee
duration: 20000,
    //gap in pixels between the tickers
    //gap: 50,
    //time in milliseconds before the marquee will start animating
    delayBeforeStart: 0,
    //'left' or 'right'
    direction: 'left',
    //true or false - should the marquee be duplicated to show an effect of continues flow
    duplicated: true ,
    pauseOnHover: true
});
</script>
</div>


	<div class="col-12 col-lg-5">
		
		<?php if(isset($encuesta)): ?>
		<div class="row">
			<div class="col-12">
				<div class="colorBackground_Titulo">	
					<h2 class="colortitulo" style="margin-left: 10px; margin-top: 10px; margin-bottom: 10px;"><i class="fa fa-poll-h"></i> ENCUESTA</h2>
				</div>
				<section>
					<div style="width:70%" class="mx-auto">
						<div class="card encuesta-card">
							<?php if(isset($encuesta)): ?>
							<form action="" method="POST">
								<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">
								<div class="card-header">
								<h5><?php echo e($encuesta->nombre); ?></h5>
								</div>
								<div class="card-body">
									<h5 class="card-title"><strong><?php echo e($encuesta->nombre); ?></strong></h5>
									<div id="encuesta-section">
										<?php echo $__env->make('encuestas.section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									</div>
								</div>
								<div class="card-footer text-muted">
									<?php if(Session::get('poll_voted') != $encuesta->id): ?>
									<button type="button" id="votar_btn" class="btn btn-dark text-center btn-block">Votar</button>
									<?php endif; ?>
									<button type="button" id="mostrar_btn" class="btn text-center btn-light border border-dark btn-block">Ver resultados</button>
									<button style="display:none" type="button" id="regresar_btn" class="btn text-center btn-light border border-dark btn-block">Regresar</button>
								</div>
							</form>
							<?php else: ?>
							<div class="card-header">
								No hay encuesta
							</div>
							<div class="card-body">
								<h4 class="card-title">No hay encuesta actualmente</h4>
							</div>
							<div class="card-footer text-muted">
							</div>
							<?php endif; ?>
						</div>
					</div>
				</section>
			</div>
		</div>
		<?php endif; ?>
		<div class="row">
			<div class="col-12" style="margin-bottom:40px">
				<div class="colorBackground_Titulo">	
					<h2 class="colortitulo" style="margin-left: 10px; margin-top: 10px; margin-bottom: 10px;"><i class="fas fa-exclamation-circle"></i> NOTICIAS</h2>
				</div>
				<!-- NOTICIA -->
			
				<section class="slide-wrapper slide-vertical">
					<div class="container cont-vertical">
						<div id="carouselNoticias" class="carousel slide carousel-vertical" data-ride="carousel">
							<ol class="carousel-indicators indicator-vertical">
								<?php $count=0;?>
								<?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li data-target="#carouselNoticias" data-slide-to="<?php echo e($count); ?>" <?php if($count==0): ?> class="active" <?php endif; ?>></li>
									<?php $count=$count+1;?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ol>
							<div class="carousel-inner inner-vertical ">
								<a class="carousel-control-prev carousel-control-prev-vertical" href="#carouselNoticias" role="button" data-slide="prev">
									<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								</a>
								<?php $count=0;?>
								<?php $__empty_1 = true; $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<div class="carousel-item item-vertical <?php if($count == 0): ?> active <?php endif; ?>">
										<?php $count=$count+1;?>
			
									<div class="noticia">
										<div class="row">
											<div class="col-4" style="padding-righ:0">
												<div class="noticia-img-container  mx-auto">
													<img src="img/<?php echo e($noticia->imagen); ?>" class="noticia-img" alt="">	
												</div>
											</div>
											<div class="col-8">
												<div class="noticia-content">
													<strong><h4 class="noticia-letras"><?php echo e($noticia->titulo); ?></h4></strong>
													<p class="noticias-letras2"><?php echo e($noticia->descripcion); ?></p>
												</div>
												<div class="noticia-likes">
													<span class="likes badge badge-red">Likes: <span class="badge bg-light text-dark" id="likes_num_<?php echo e($noticia->id); ?>"><?php echo e($noticia->likes); ?></span> <i class="fas fa-heart"></i></span>
													<a href="javascript:void(0);" onclick="aumentarMegusta(<?php echo e($noticia->id); ?>)" class="btn btn-primary buttonLike">Me gusta <i class="far fa-thumbs-up"></i></a>
												</div>
											</div>

										</div>
										
										
									</div>
								</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<div class="carousel-item item-vertical active">
									<div class="noticia">
										<div class="row">
											<div class="col-12 text-center">
												<div class="noticia-content">
													<br>
													<br>
													<br>
													<br>
													<strong><h3>No hay noticias actualmente</h3></strong>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php endif; ?>
								<a class="carousel-control-next carousel-control-next-vertical" href="#carouselNoticias" role="button" data-slide="next">
									<span class="carousel-control-next-icon" aria-hidden="true"></span>
								</a>
							</div>
						</div>
					</div>
				</section>
			</div>

			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- Anuncio 1 -->
				<ins class="adsbygoogle"
				     style="display:block"
				     data-ad-client="ca-pub-2298464716816209"
				     data-ad-slot="1602129934"
				     data-ad-format="auto"
				     data-full-width-responsive="true"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
	</div>
	
	
	<script>
	$('#carouselNoticias').carousel({
				interval: false
			});	
			$("#carouselNoticias").on("touchstart", function(event){
	
				var yClick = event.originalEvent.touches[0].pageY;
				$(this).one("touchmove", function(event){
	
					var yMove = event.originalEvent.touches[0].pageY;
					if( Math.floor(yClick - yMove) > 1 ){
						$(".carousel-vertical").carousel('next');
					}
					else if( Math.floor(yClick - yMove) < -1 ){
						$(".carousel-vertical").carousel('prev');
					}
				});
				$(".carousel-vertical").on("touchend", function(){
					$(this).off("touchmove");
				});
			});
	</script>

</div>
<div class="col-12 col-lg-2" style="font-size: 14px;">
	<div class="colorBackground_Titulo">	
		<strong>
			<h5 class="colortitulo" style="margin-left: 10px; margin-top: 10px; margin-bottom: 10px;"><i class="fas fa-address-card"></i> QUE OPINAN NUESTROS CLIENTES?</h5>
		</strong>


	</div>
	<hr>
	<div class='marquee' style="color: white;">
		<?php $count =0?>
		<?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="comcontainer darker">
			<div class="row">
				<div class="col-3">
					<?php 
					if(!is_null($comentario->image)) 
						echo'<img src="img/'.$comentario->image.'" alt="Avatar">';
					else echo '<img src="img/pelota.png" alt="Avatar">';
					?>
				</div>
				<div class="col">
					<h5><?php echo e($comentario->nombre); ?></h5>
					<p><?php echo e($comentario->texto); ?></p>
				</div>
			</div>
		</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<script>
		$('.marquee').marquee({
//speed in milliseconds of the marquee
duration: 10000,
    //gap in pixels between the tickers
    //gap: 50,
    //time in milliseconds before the marquee will start animating
    delayBeforeStart: 0,
    //'left' or 'right'
    direction: 'down',
    //true or false - should the marquee be duplicated to show an effect of continues flow
    duplicated: true ,
    pauseOnHover: true
});
</script>
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" style="padding: 10px">
	<div class="carousel-inner">

		<?php  $count=0;  ?>
		<?php $__currentLoopData = $portal2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php  $count++; ?>
		<div class="carousel-item <?php if($count==1) echo 'active';?>">
			<img class="d-block w-100" src="img/<?php echo e($portal->imagen); ?>" alt="First slide" height="120px">
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
</div>
<div class="container top">	
	<br>
	<strong>	Articulos mas vendidos del dia
	</strong>
	<hr style="background-color: white !important; border: 1px solid;">
	<?php $i=1; ?>
	<?php $__currentLoopData = $articulo_mas_vendido_semana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
	<strong><?php echo $i++; ?> </strong>. <?php echo e($articulo->name); ?> | <?php echo e($articulo->category); ?>

	<br>
	<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<br>		
</div>
</div>
</div>
<br>	
</div>
</div>


<script>

$("#votar_btn").click(function(){
    var CSRF_TOKEN = $('#token').val();
    $.ajax({
        url: '/encuestas/votar/'+$('input[name="respuesta"]:checked').val(),
        type: 'POST',
        data: {
            _token: CSRF_TOKEN, 
            id:$('input[name="respuesta"]:checked').val(),
        },
        dataType: 'JSON',
        success: function (data) { 
            if(data.success){
				$('#encuesta-section').fadeOut();
				$('#encuesta-section').load('/encuestas/user/show', function() {
					$('#encuesta-section').fadeIn();
					$('.encuesta-option').hide();
				$('.encuesta-resultado').show();
				});
				$("#votar_btn").attr("disabled", true);;	
				$('#regresar_btn').show();
				$('#votar_btn').hide();
				$('#mostrar_btn').hide();
            }

            $("#message").text(data.msg); 

        },
        error: function (data){
            $("#message").text(data.msg); 
        }
        
    }); 
});
$("#mostrar_btn").click(function(){
	$('.encuesta-option').hide();
	$('.encuesta-resultado').show();
	$('#regresar_btn').show();
	$('#votar_btn').hide();
	$('#mostrar_btn').hide();
});
$("#regresar_btn").click(function(){
	$('.encuesta-option').show();
	$('.encuesta-resultado').hide();
	$('#regresar_btn').hide();
	$('#votar_btn').show();
	$('#mostrar_btn').show();
});
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantillaWeb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>