<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> Todos los Cupones</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">

				<div class="tile-body"> </div>
                    <div class="table-responsive">
                        <br>
                        <div class="btn-group" role="group" aria-label="Basic example">
                                  <a href="/cupones/crear" class="btn btn-primary">
                            Agregar Nuevo Cupon
                            </a>
                    </div>
				<br>
				<br>
				
			</div>
			<br>
			<div id="select" class="panel-body">
				<strong>Cantidad total de cupones: </strong><?php echo e($cupones_cantidad); ?>

				<?php echo $__env->make('admin.misc.pagination', ['paginator' => $cupones], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				<table class="table table-responsive">
					<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">
					<br>
					<thead>
						<tr>
							<th scope="col">Id</th>
							<th scope="col">Id del creador</th>
							<th scope="col">Descuento</th>
                            <th scope="col">Disponibles</th>
                            <th scope="col">Codigo</th>
                            <th scope="col">Nota de cupon</th>
							<th></th>
						</tr>
					</thead>
					<tbody>

						<?php $__currentLoopData = $cupones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>

							<th scope="row"><?php echo $cupon->id ?></th>

							<td>
								
								<?php echo $cupon->fk_empleado.' - '.$cupon->pertenece_fk_empleado->name.' '.$cupon->pertenece_fk_empleado->lastname?>
							</td> 
							<td>
                                <?php echo $cupon->descuento.' $';?>
							</td>
							<td>
                                <?php echo $cupon->disponible?>
                            </td>
                            <td>
                                <?php echo $cupon->codigo?>
                            </td>
                            <td>
                                <?php echo $cupon->nota_cupon?>
                            </td>
                            <td>
								<a href="/cupones/editar/<?php echo e($cupon->id); ?>" class="btn btn-primary">Editar cupon</a>
								<a href="/cupones/eliminar/<?php echo e($cupon->id); ?>" class="btn btn-danger">Eliminar cupon</a>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<?php echo $__env->make('admin.misc.pagination', ['paginator' => $cupones], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>


		</div>

	</div>
</div>
</main>
<?php echo $__env->make('modal.eliminar-imagen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script
src="https://code.jquery.com/jquery-3.3.1.js"
integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>