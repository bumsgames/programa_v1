<?php $__env->startSection('content'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> Menu Usuario</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Menu Usuario</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="row"> 
          <div class="col"> 
            <?php echo $__env->make('admin.misc.flash-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <center>
              <br>
              <h2>Crear usuario nuevo</h2>
              <form enctype="multipart/form-data" files="true" action="/crear_usuario" method="post">
                <input hidden="" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="row"> 
                  <div class="col"> 
                    <div class="form-group">
                      <label for="">Nombre de usuario</label>
                      <input type="text" 
                      class="form-control" 
                      name="name"
                      value="<?php echo e(old('name')); ?>" 
                      autocomplete="nope">
                    </div>
                  </div>
                  <div class="col"> 
                    <div class="form-group">
                      <label for="">Apellido de usuario</label>
                      <input type="text" 
                      class="form-control" 
                      name="lastname"
                      value="<?php echo e(old('lastname')); ?>" 
                      autocomplete="nope">
                    </div>
                  </div>
                </div>
                
                
                <div class="form-group">
                  <label for="">Correo de usuario</label>
                  <input type="text" 
                  class="form-control" 
                  name="email"
                  value="<?php echo e(old('email')); ?>" 
                  autocomplete="off">
                </div>
                <div class="form-group">
                  <label for="">Nickname de usuario</label>
                  <input type="text" 
                  class="form-control" 
                  id="nickname"
                  name="nickname"
                  value="<?php echo e(old('nickname')); ?>" 
                  autocomplete="off">
                </div>
                <div class="form-group">
                  <label for="">Nivel de usuario</label>
                  <input type="number" 
                  class="form-control " 
                  name="level"
                  value="<?php echo e(old('level')); ?>" 
                  autocomplete="off">
                </div>
                <div class="form-group">
                  <label for="image">Password de Usuario</label>
                  <input type="password" 
                  class="form-control" 
                  name="password"
                  value="<?php echo e(old('password')); ?>" 
                  autocomplete="off">
                </div>

                <div class="form-group">
                  <label for="image">Imagen de Usuario</label>
                  <br>  
                  <br>  
                  
                  <div class="custom-file">
                    <input name="image" id="inputFile1" type="file" class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang">Seleccionar Archivo</label>
                  </div>
                  <br> 
                  <br>   
                  <img id="img1" width="175"><br/>

                </div>

                <br>
      <!-- <div class="form-group">
        <label for="">Password</label>
        <input type="text" class="form-control" name="tal">
      </div> -->
      <button class="btn btn-primary" type="submit">Guardar</button>
    </form>
  </center>
</div>
<div class="col"> 
  <br>  
  <center>
    <h2>Lista de Usuarios</h2>
  </center>
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nombre y Apellido</th>
          <th scope="col">Nickname</th>
          <th scope="col">Botones</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo $i; $i++; ?></th>
          <td><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></td>
          <td><?php echo e($user->nickname); ?></td>
          <td><button type="button"
           class="btn btn-secondary"
           id="modificar_user"
           data-toggle="modal" data-target=".modificar_user"
           onclick="modificar_user(<?php echo e($user->id); ?>);">Modificar</button>
          <button type="button"
           class="btn btn-secondary"
           id=""
           data-toggle="modal" data-target=".bd-example-modal-lg3"
           onclick="mandarid(<?php echo e($user->id); ?>);">Eliminar</button>
         </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tr>
     </tbody>
   </table>
 </div>
</div>
</div>
</div>

</div>
</div>

</main>

<?php echo $__env->make('modal.modificar_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.eliminar_usuario', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
  $('#nickname').on('keypress',function(){
    $('#nickname').val($('#nickname').val().replace(/ /g, ''));
  });
  $('#nickname').change(function(){
    $('#nickname').val($('#nickname').val().replace(/ /g, ''));
  });
  $('#nickname_modificar').on('keypress',function(){
    $('#nickname_modificar').val($('#nickname_modificar').val().replace(/ /g, ''));
  });
  $('#nickname_modificar').change(function(){
    $('#nickname_modificar').val($('#nickname_modificar').val().replace(/ /g, ''));
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>