<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> <?php echo e($title); ?></h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">				
				<div class="table-responsive">
				
					<table class="table">
						<thead>
							<tr>
                                <th scope="col">#</th>
								<th scope="col">Nombre y Apellido</th>
                                <th scope="col">Juego</th>
                                <th scope="col">Categoria</th>
								<th scope="col">N# de Whatsapp</th>
                                <th></th>
							</tr>
						</thead>
						<tbody>	
                            <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="align-middle"><?php echo e($oferta->id); ?></td>
                                <td class="align-middle"><?php echo e($oferta->name); ?></td>
                                <td class="align-middle"><?php echo e($oferta->articulo->name); ?></td>
                                <td class="align-middle"><?php echo e($oferta->articulo->pertenece_category->category); ?></td>
                                <td class="align-middle"><?php echo e($oferta->telefono); ?></td>
                                <td class="align-middle">
                                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#veroferta" id="modaltrigger" onclick="modaltrigger(<?php echo e($oferta->id); ?>,'<?php echo e($oferta->name); ?>','<?php echo e($oferta->articulo->name); ?>','<?php echo e($oferta->articulo->pertenece_category->category); ?>','<?php echo e($oferta->telefono); ?>','<?php echo e($oferta->oferta); ?>','<?php echo e($oferta->articulo->price_in_dolar); ?>$',<?php echo e($oferta->estado); ?>)">
                                        Ver Oferta
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            </tbody>
		            </table>
	            </div>
	<?php if($ofertas->hasPages()): ?>
        <ul class="pagination justify-content-center">
            
            <?php if($ofertas->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link"><</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($ofertas->previousPageUrl()); ?>" rel="prev"><</a></li>
            <?php endif; ?>

            <?php if($ofertas->currentPage() > 3): ?>
                <li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($ofertas->url(1)); ?>">1</a></li>
            <?php endif; ?>
            <?php if($ofertas->currentPage() > 4): ?>
                <li class="page-item"><span class="page-link">...</span></li>
            <?php endif; ?>
            <?php $__currentLoopData = range(1, $ofertas->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i >= $ofertas->currentPage() - 2 && $i <= $ofertas->currentPage() + 2): ?>
                    <?php if($i == $ofertas->currentPage()): ?>
                        <li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($ofertas->url($i)); ?>"><?php echo e($i); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($ofertas->currentPage() < $ofertas->lastPage() - 3): ?>
                <li class="page-item"><span class="page-link">...</span></li>
            <?php endif; ?>
            <?php if($ofertas->currentPage() < $ofertas->lastPage() - 2): ?>
                <li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($ofertas->url($ofertas->lastPage())); ?>"><?php echo e($ofertas->lastPage()); ?></a></li>
            <?php endif; ?>

            
            <?php if($ofertas->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($ofertas->nextPageUrl()); ?>" rel="next">></a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">></span></li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>


</div>

</div>
</div>

</main>
<!-- Modal -->
<div class="modal fade" id="veroferta" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Oferta de cliente #<span class="titulomodal"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                    <h5>Cliente: &nbsp;<span style="font-weight:normal" class="cliente"></span></h5>
                    <h5># de Whatsapp: &nbsp;<span style="font-weight:normal" class="telefono"></span></h5>
                    <h5>Artículo: &nbsp;<span style="font-weight:normal" class="articulo"></span></h5>
                    <h5>Categoría: &nbsp;<span style="font-weight:normal" class="categoria"></span></h5>
                    <h5>Precio: &nbsp;<span style="font-weight:normal" class="precio"></span></h5>
                    <h5>Oferta: &nbsp;</h5>
                    <h5><span style="font-weight:normal" class="oferta"></span></h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button id="aprobar-link" class="btn btn-success">Aprobar</button>               
                <button id="rechazar-link" class="btn btn-danger">Rechazar</button>
            </div>
        </div>
    </div>
</div>
<script src="http://127.0.0.1:8000/js/jquery3.min.js"></script>
<script>
    $('#veroferta').on('show.bs.modal', event => {
        var button = $(event.relatedTarget);
        var modal = $(this);        
    });
    
    function modaltrigger(id, nombre, articulo, categoria, telefono, oferta,precio,estado){
        $('.titulomodal').text(id);
        $('.cliente').text(nombre);
        $('.articulo').text(articulo);
        $('.categoria').text(categoria);
        $('.telefono').text(telefono);
        $('.precio').text(precio);
        $('.oferta').text(oferta);
        if(estado == 0){
            $('#aprobar-link').show();
            $('#rechazar-link').show();
        }
        else{
            $('#aprobar-link').hide();
            $('#rechazar-link').hide();
        }
    }

    $('#aprobar-link').click(function(){
        $.get( "/ofertas_cliente/aprobar/"+$('.titulomodal').text(), function( data ) {
            if(data.success){
                $('#veroferta').modal('hide')
                swal('Oferta Aprobada!','La oferta ha sido aprobada correctamente','success');
            }
            else{
                $('#veroferta').modal('hide')
                swal('Error!','Algo ha salido mal, reinicia la pagina y vuelve a intentarlo.','error');
            }
        });
    });

    $('#rechazar-link').click(function(){
        $.get( "/ofertas_cliente/rechazar/"+$('.titulomodal').text(), function( data ) {
            if(data.success){
                $('#veroferta').modal('hide')
                swal('Oferta Rechazada','La oferta ha sido rechazada correctamente','success');
            }
            else{
                $('#veroferta').modal('hide')
                swal('Error!','Algo ha salido mal, reinicia la pagina y vuelve a intentarlo.','error');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>