<?php $__env->startSection('content'); ?>`
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i>Guias y tutoriales</h1>
			<p>Llegamos para hacer la diferencia</p>
		</div>

</div>
<div class="row">
	<div class="col-md-12">
		<div class="tile">
			<?php echo $__env->make('plantilla_guia', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>