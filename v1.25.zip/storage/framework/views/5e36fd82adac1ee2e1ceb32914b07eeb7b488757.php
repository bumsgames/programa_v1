<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<style type="text/css">
	</style>
</head>
<body>
	<center>Busqueda david</center>
	<strong>Inicio:</strong> <?php echo e($inicio); ?> <strong>Final:</strong> <?php echo e($fin); ?>

	<br> 
	<strong>USUARIO: </strong> 
	<?php if($usuario == 0): ?>
	Todos los usuarios
	<?php else: ?>
	<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($persona->id == $usuario): ?>
	<?php echo e($persona->name); ?> <?php echo e($persona->lastname); ?>

	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th scope="col">#</th>
				<th scope="col">Articulo</th>
				<th scope="col">Duennos</th>
				<th scope="col">Total</th>
			</tr>
		</thead>
		<?php $count_movimientos=0;?>
		<?php $ganancia_neta=0;?>
		<tbody>
			<?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $count_movimientos+=1?>
			<tr>
				<td> 
					<b><?php echo e($count_movimientos); ?></b>. <?php echo e($movimiento->created_at); ?>

				</td>
				<td>
					<?php if(starts_with($movimiento->movimiento->description, 'Venta Realizada')): ?>
					<?php $__currentLoopData = $movimiento->movimiento->venta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento->movimiento->venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<strong>Artículo: </strong><?php echo e($movimiento->movimiento->venta->articulo->name); ?> | <?php echo e($movimiento->movimiento->venta->articulo->pertenece_category->category); ?> <b>
						(<?php echo e($movimiento->movimiento->venta->articulo->email); ?>)
					</b>
					<br>
					<strong>Cantidad: </strong><?php echo e($movimiento->movimiento->cantidad); ?>

					<br>
					<strong>Inversion: </strong><?php echo e($movimiento->movimiento->inversion); ?> $
					<br>
					<strong>Cliente: </strong><?php echo e($movimiento->movimiento->venta->cliente->name); ?> <?php echo e($movimiento->movimiento->venta->cliente->lastname); ?>

					<?php break;?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					NO APLICA
					<?php endif; ?>
				</td>
				<td>
					<b><?php echo e($count_movimientos); ?></b>. <strong>Entidad: </strong><?php echo e($movimiento->movimiento->entidad); ?>

					<br>
					<br>
					<?php if($movimiento->movimiento->type == 'bums'): ?>
					<?php 
					$transaccion="";
					$contar_x=0;
					$alterno=0;
					?>
					<?php $__currentLoopData = $movimiento->movimiento->usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($x->pivot->porcentaje == 0): ?>
					<?php $alterno++; ?>
					<strong>Venta realizada por: </strong><?php echo e($x->name); ?> <?php echo e($x->lastname); ?> (10% = <?php echo e(number_format(((10 / 100) *  $movimiento->movimiento->price), 0, ',', '.')); ?> <?php echo e($movimiento->movimiento->moneda->sign); ?>)

					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<br>
					Acciones
					<br>
					<?php if($movimiento->movimiento->type == 'bums'): ?>
					<?php 
					$transaccion="";
					$contar_x=0;
					?>
					<?php $__currentLoopData = $movimiento->movimiento->usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($x->pivot->porcentaje != 0): ?>
					<?php if($alterno == 0): ?>
					<strong>Dueño:</strong> (<?php echo e($x->name); ?> <?php echo e($x->lastname); ?>) | <?php echo e(number_format((($x->pivot->porcentaje / 100) *  $movimiento->movimiento->price), 0, ',', '.')); ?> <?php echo e($movimiento->movimiento->moneda->sign); ?> (<?php echo e($x->pivot->porcentaje); ?>%)
					<br>
					<?php else: ?>
					
					
					<strong>Dueño:</strong> (<?php echo e($x->name); ?> <?php echo e($x->lastname); ?>) | <?php echo e(number_format((($x->pivot->porcentaje / 100) * ( $movimiento->movimiento->price - ($movimiento->movimiento->price * 0.10 ))), 0, ',', '.')); ?> <?php echo e($movimiento->movimiento->moneda->sign); ?> (<?php echo e($x->pivot->porcentaje); ?>%)
					<br>
					<?php endif; ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<br>
					<br>
					NOTA: <b><?php echo e($movimiento->movimiento->note_movimiento); ?> </b>
					<br>
					<br>
				</td>
				<td style="width: 300px;">
					<strong>Precio de venta: </strong> <?php echo e(number_format($movimiento->movimiento->price * $movimiento->movimiento->cantidad, 0, ',', '.')." ".$movimiento->movimiento->moneda->sign); ?>

					<br>
					<strong>Precio del dolar del día: </strong><?php echo e(number_format($movimiento->movimiento->dolardia, 0, ',', '.')); ?> Bs
					<br>
					<b>Precio de venta ($): </b><?php echo e(number_format(($movimiento->movimiento->price / $movimiento->movimiento->moneda->valor), 2, ',', '.')); ?> $
					<br>
					<b>Ganancia neta ($)</b>: <?php echo e(number_format(($movimiento->movimiento->price / $movimiento->movimiento->moneda->valor) - $movimiento->movimiento->inversion, 2, ',', '.')); ?> $

					<?php $ganancia_neta+= (($movimiento->movimiento->price / $movimiento->movimiento->dolardia) - $movimiento->movimiento->inversion) ?>
					
				</td>
			</tr>
			<?php $alterno=0; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<br>
	<div style="padding:0 20px;">
	<h4><strong>Inicio:</strong> <?php echo e($inicio); ?> <strong>Final:</strong> <?php echo e($fin); ?></h4>
	<h6>
		<br> 
	<strong>USUARIO: </strong> 
	<?php if($usuario == 0): ?>
	Todos los usuarios
	<?php else: ?>
	<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($persona->id == $usuario): ?>
	<?php echo e($persona->name); ?> <?php echo e($persona->lastname); ?>

	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	</h6>
	<br>
		<h1>Ganancia neta total de la empresa: <?php echo e(number_format($ganancia_neta, 2, ',', '.')); ?> $</h1>
		<hr style="border-color: black; border: solid;">
		<h1>Total recibido por banco:</h1>
		<ul>
			<?php $__currentLoopData = $movi_banco; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><h4><strong><?php echo e($banco->entidad); ?>:</strong> <?php echo e(number_format($banco->porbanco, 2, ',', '.')); ?> $</h4></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<hr style="border-color: black; border: solid;">
		<h1>Total recibido por categoria:</h1>
		<ul>
			<?php $__currentLoopData = $movi_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><h4><strong><?php echo e($categoria->category); ?>:</strong> <?php echo e(number_format($categoria->porcate, 2, ',', '.')); ?> $</h4></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>


	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>