<?php $__env->startSection('content'); ?>
<br>
<br>
<style>
.btn-categorias{
	margin: 20px;
	padding: 10px !important;
}
.fondoBlanco{
	color: black !important;
	background: white !important;
}
</style>
<div class="container-fluid">

	<div class="tile fondoBlanco sidebarpanel" style="padding-left:0">

		
		<br>
		<style>	
.list-group .active{
	background: #ff0005;
	border: none !important;
	opacity: 0.8 !important;
}

.hr_negro{
    border: 1px black solid;
}
	</style>
    <div class="row">
					<div class="col-2 side-panel-col">
						<div class="list-group group-panel" id="list-tab" role="tablist">
                            <span class="list-group-item list-group-item-action panel-item-main " >
                                <div class="row">
                                    <div class="col-2">    
                                        <i style="vertical-align:-100%" class="fa fa-user fa-lg"></i> 
                                    </div>
                                    <div class="col-10"> 
                                        <strong>Mi cuenta</strong><br>
                                        Bienvenido, <?php echo e($user->name); ?> <?php echo e($user->lastname); ?><br>
                                    </div>
                                </div>
                            </span>
							<a class="list-group-item list-group-item-action panel-item active" id="list-digital-list" data-toggle="list" href="#list-digital" role="tab" aria-controls="digital">Mis productos</a>
							<a class="list-group-item list-group-item-action panel-item " id="list-principal-list" data-toggle="list" href="#list-principal" role="tab" aria-controls="principal">Mis compras</a>
                        </div>
                        
					</div>
					<div class="col-10">
						<div class="tab-content letraNegra ayudabody" id="nav-tabContent">
							<div class="tab-pane fade show active" id="list-digital" role="tabpanel" aria-labelledby="list-digital-list">
                                <h1 class="panel-title">MIS PRODUCTOS</h1>
                                <br>
                            <table class="table">
                                <thead class="miscomprashead">
                                <tr >
                                    <th>#</th>
                                    <th>Nombre del producto</th>
                                    <th>Categoria</th>
                                    <th>Email</th>
                                    <th>Clave</th>
                                    <th>Información</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $count=0;?>
                                <?php $__currentLoopData = $articulosmios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="miscompras">
                                    <td><?php echo e(++$count); ?></td>
                                    <?php if(isset($articulos->venta->articulo->name)): ?>
                                        <td><?php echo e($articulos->venta->articulo->name); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($articulos->articulo->name); ?></td>
                                    <?php endif; ?>
                                    <?php if(isset($articulos->venta->articulo->name)): ?>
                                        <td><?php echo e($articulos->venta->articulo->pertenece_category->category); ?></td>
                                    <?php elseif($articulos->articulo->id =='2'): ?>
                                        <td>ARTICULO DEVUELTO</td>
                                    <?php else: ?>
                                        <td><?php echo e($articulos->articulo->pertenece_category->category); ?></td>
                                    <?php endif; ?>
                                    
                                    <?php if($articulos->articulo->id != 2): ?>                                    
                                    <?php if(in_array($articulos->articulo->category,[1,2,8,9,12])): ?>
                                    <td><?php echo e($articulos->articulo->email); ?></td>
                                    <?php else: ?>
                                    <td>-</td>
                                    <?php endif; ?>

                                    <?php else: ?>
                                    <td>-</td>
                                    <?php endif; ?>
                                    <td>
                                        <?php if(in_array($articulos->articulo->category,[2,9])): ?>
                                        <?php echo e($articulos->articulo->password); ?>

                                        <?php endif; ?>
                                        <?php if(!in_array($articulos->articulo->category,[2,9])): ?>
                                        -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($articulos->articulo->id == '2'): ?>
                                        <?php echo $articulos->informacion;?>
                                        <?php else: ?>
                                            <?php if(in_array($articulos->articulo->category,[2,9])): ?>
                                                Recuerda que no debes cambiar la clave <br>de esta cuenta
                                            <?php endif; ?>
                                            <?php if(in_array($articulos->articulo->category,[1,5,8])): ?>
                                                Recuerda que no debes jugar desde el <br>usuario de donde descargaste el juego
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if(in_array($articulos->articulo->category,[1,2,5,8,9,12])&&$articulos->articulo->id !='2'): ?>
                                            <br>
                                            <br>Recuerda que puedes utilizar tus juegos <br>como parte ddel pago
                                        <?php endif; ?>
                                    </td>
                                    <script>
                                        $('#textimport').text('');
                                    </script>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
							</div>
							<div class="tab-pane fade" id="list-principal" role="tabpanel" aria-labelledby="list-principal-list">   
                            <h1 class="panel-title">MIS COMPRAS</h1>
                                <br>
                            <table class="table">
                                <thead class="miscomprashead">
                                <tr >
                                    <th>#</th>
                                    <th>Nombre del producto</th>
                                    <th>Categoria</th>
                                    <th>Fecha de la compra</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $count=0;?>
                                <?php $__currentLoopData = $articulocomprado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="miscompras">
                                    <td><?php echo e(++$count); ?></td>
                                    <td><?php echo e($articulos->name); ?></td>
                                    <td><?php echo e($articulos->catname); ?></td>
                                    <td><?php echo e($articulos->fecha); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
									</div>
					
									
						</div>
					</div>
</div>
			

	</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillaWeb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>