<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> <?php echo e($title); ?> 
				<?php if($title != 'Todas las cuentas'): ?>
				(<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?>)</h1>
				<?php endif; ?>
		</div>
		<ul class="app-breadcrumb breadcrumb">
			<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
			<li class="breadcrumb-item"><a href="#"><?php echo e($title); ?> </a></li>
		</ul>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<button data-toggle="modal" class="btn btn-primary" data-target=".registrar_cuenta">Crear nueva cuenta</button>
				<br>	
				<br>
				<input type="text" placeholder="Buscar" class="form-control" id="buscador">
				<br>

				<?php echo $__env->make('modal.registrar_cuenta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Informacion</th>
								<th scope="col">Saldo</th>
								<th scope="col">Botones</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=1; ?>
							<?php $__currentLoopData = $cuentas_tuyas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td>
									<?php echo $i; $i++; ?>	
								</td>
								<td>
									<strong>	
										Entidad:
									</strong>
									<?php echo e($cuenta->entidad); ?>	
									<br>	
									<br>	
									<strong>	
										Correo:
									</strong>
									<?php echo e($cuenta->correo); ?>


									<br>	
									<br>	
									<strong>	
										Password:
									</strong>
									<?php echo e($cuenta->password); ?>

									<br>	
									<br>	
									<strong>	
										Nota:
									</strong>
									<?php echo e($cuenta->note_cuenta); ?>

								</td>	
								<td>
									<?php $saldo = 0; $coin = ''; ?>
									<?php $__currentLoopData = $cuenta->ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
									<?php $saldo += $orden->movimiento->price; ?>
									<?php $coin = $orden->movimiento->moneda->sign;?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php echo e(number_format($saldo, 0, ',', '.')); ?> <?php echo e($cuenta->moneda->coin); ?>

								</td>
								<td>
									<button class="btn btn-primary" data-toggle="modal" data-target=".modificar-cuent" Onclick="buscar_cuent(<?php echo e($cuenta->id); ?>);">Modificar</button>

									<button class="btn btn-primary price" data-toggle="modal" data-target=".registrar_orden" onclick="modal_orden(<?php echo e($cuenta->id); ?>, '<?php echo e($cuenta->correo); ?>', '<?php echo e($cuenta->entidad); ?>')">Crear orden</button>
									 <button class="btn btn-primary " data-toggle="modal" data-target=".eliminar-cuent" Onclick="mandaridM(<?php echo e($cuenta->id); ?>);">Eliminar</button>
										<br>
										<br>		
									    <form action="ordenes_cuenta" method="post">
										<?php echo e(csrf_field()); ?>

										
										<input type="text" name="id" value="<?php echo e($cuenta->id); ?>" hidden="">
                                         <button class="btn btn-secondary" type="submit">Ver ordenes</button></a>
									</form>	
									
									<?php echo $__env->make('modal.registrar_orden', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php echo $__env->make('modal.eliminar-cuenta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									<?php echo $__env->make('modal.modificar_cuenta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
									
								</td>
							</tr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>
				</div>


			</div>

		</div>
	</div>

</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>