
<p class="card-text">

    <?php $opciones = 0;?>
    <?php $total = 0;?>
    <?php $__currentLoopData = $encuesta->Options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total+=$option->contador?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($total == 0){ $total = 1;}?>
    <?php if(Session::get('poll_voted') != $encuesta->id): ?>

    <?php $__currentLoopData = $encuesta->Options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $opciones++;?>
    <style type="text/css">
        .a{
            background-color: rgba(40, 0, 0, 0.8);
        border-radius: 50px;
        padding: 5px;
        }

        .division_encuesta{
            background-color: rgba(10, 0, 0, 0.8); 
            padding: 5px; 
            margin: 10px;
            color: white;
        }

        .custom-radio, .custom-control-input, .custom-control-label{
            cursor: pointer;
        }

       input[type=radio]:checked ~ label{
          color: #0DFF92;
          opacity: 0.7;
          font-size: 22px;
          transition: all 0.3s ease-in-out;
        }
    </style>
    <div class="division_encuesta">
        
        <div class="custom-control custom-radio encuesta-option">
            <input type="radio" class="custom-control-input" id="option_<?php echo e($opciones); ?>" name="respuesta" value="<?php echo e($option->id); ?>">
            <label class="custom-control-label" for="option_<?php echo e($opciones); ?>"><?php echo e($option->nombre); ?></label>
        </div>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <?php else: ?>
    <div class="encuesta-option">
         <?php $__currentLoopData = $encuesta->Resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="encuesta-resultado2" >
                <?php echo e($resultado->nombre); ?><span class="float-right"><?php echo e($resultado->contador); ?> (<?php echo e(number_format ( $resultado->contador * 100/$total , 2 , "," , "." )); ?>%)</span>
                <div class="progress mb-1">
                    <div id="progress_<?php echo e($resultado->id); ?>" class="progress-bar" role="progressbar" 
                    style="width: <?php echo e(number_format ( $resultado->contador * 100/$total , 0 , "," , "." )); ?>%;background-color:<?php echo e($resultado->color); ?>"
                        aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <?php $__currentLoopData = $encuesta->Resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="encuesta-resultado" style="display:none">
        <?php echo e($resultado->nombre); ?><span class="float-right"><?php echo e($resultado->contador); ?> (<?php echo e(number_format ( $resultado->contador * 100/$total , 2 , "," , "." )); ?>%)</span>
        <div class="progress mb-1">
            <div id="progress_<?php echo e($resultado->id); ?>" class="progress-bar" role="progressbar" 
            style="width: <?php echo e(number_format ( $resultado->contador * 100/$total , 0 , "," , "." )); ?>%;background-color:<?php echo e($resultado->color); ?>"
                aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</p>
