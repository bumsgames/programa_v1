<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> Imagenes</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">

				<div class="tile-body"> </div>
				<form enctype="multipart/form-data" files="true" action="<?php echo e(url('portal')); ?>" method="POST" class="form-inline">
					<?php echo e(csrf_field()); ?>

					<input type="" name="id_creator" value="<?php echo e(Auth::id()); ?>" hidden="">
					<input type="number" class="form-control form-control-sm" name="portal" required="" placeholder="Numero de portal" autocomplete="off">
					<input type="file" name="imagen" id="inputFile1" required>
					<button class="btn btn-primary">Agregar imagen de portal</button>
				</form>
				<br>
				<img style="border: 1px solid;" id="img1" width="100%" height="auto"><br/>
				<div class="table-responsive">
					<br>
					<br>
					<!-- Modal -->
					<div aria-hidden="true" class="modal fade bd-example-modal-lg" id="modal1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-lg">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title">Agregar imagenes</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="row">
								</div>
								<div class="container">

									<form action="">

										<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">
										<div class="row">
											<div class="col">
												<div class="form-group">
													<label for="">Registrado por:</label>
													<input type="text" name="de_usuario" id="de_usuario" class="form-control" value="<?php echo e(Auth::user()->id); ?>" hidden="">
													<input type="text" class="form-control" value="<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?>" readonly="" >
												</div>
											</div>
										</div>

										<div class="col">	
											<div class="form-group">
												<label for="image">
													<strong>
														<label for="image">Imagen de Articulo</label>
													</strong>
												</label>

												<div class="custom-file">
													<input name="image" id="inputFile1" type="file" class="custom-file-input" id="customFileLang" lang="es">
													<label class="custom-file-label" for="customFileLang">Seleccionar Archivo</label>
												</div>
												<br> 
												<br>   
												<center>
													<img style="border: 1px solid;" id="img1" height="200"><br/>
												</center>


											</div>
										</div>
										<div class="modal-footer">
											<button type="button" id="xxx" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<button type="button" class="btn btn-primary" id="agregar_imagenes">Guardar</button>
										</div>
									</form>
								</div>

							</div>
						</div>
					</div>
				</div>
				<br>
				<div id="select" class="panel-body">
					<strong>Imagenes totales: </strong><?php echo e($imagenes_cantidad); ?>

					<table class="table table-responsive">
						<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">
						<br>
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Subido por:</th>
								<th scope="col">Imagen</th>
								<th scope="col">Opcion</th>
							</tr>
						</thead>
						<tbody>
							<?php $i = 1; ?>
							<?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>

								<th scope="row"><?php echo $i++; ?></th>

								<td>
									<?php echo e($imagen->pertenece_id_creator->name); ?> <?php echo e($imagen->pertenece_id_creator->lastname); ?> 

									<br>
									<br>
									<strong>Creada: </strong> <?php echo e($imagen->created_at->diffForHumans()); ?>

									<br>	
									<br>	
									<strong>Imagen del portal: </strong> <?php echo e($imagen->portal); ?>

								</td>
								<td>
									<strong>Imagen del portal: </strong> <?php echo e($imagen->portal); ?>

									<br>	
									<br>	
									<?php if($imagen->portal == 3): ?>
									<center>
										<img style="border: 1px solid;" width="250" src="img/<?php echo e($imagen->imagen); ?>" alt="" >
									</center>
									<?php else: ?>
									<center>
										<img style="border: 1px solid;" width="250" src="img/<?php echo e($imagen->imagen); ?>" alt="" >
									</center>
									<?php endif; ?>

								</td>
								<td>
									<div class="btn-group" role="group" aria-label="Basic example">

										<button type="button" 
										class="btn btn-secondary" ml-auto=""
										data-toggle="modal" data-target=".eliminar-imagen" Onclick="mandaridM(<?php echo e($imagen->id); ?>);">Eliminar</button>
									</div>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>

				</div>


			</div>

		</div>
	</div>
</main>
<?php echo $__env->make('modal.eliminar-imagen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>