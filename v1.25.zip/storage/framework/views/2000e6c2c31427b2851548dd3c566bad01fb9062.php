<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
	<center>Busqueda david</center>
	<strong>Inicio:</strong> <?php echo e($inicio); ?> <strong>Final:</strong> <?php echo e($fin); ?>

	<br> 
	<strong>USUARIO: </strong> 
	<?php if($usuario == 0): ?>
	Todos los usuarios
	<?php else: ?>
	<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($persona->id == $usuario): ?>
	<?php echo e($persona->name); ?> <?php echo e($persona->lastname); ?>

	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th scope="col">#</th>
				<th scope="col">Articulo</th>
				<th scope="col">Venta externa</th>
				<th scope="col">Duennos</th>
				<th scope="col">Total</th>
			</tr>
		</thead>
		<?php $count_movimientos=0;?>
		<?php $ganancia_neta=0;?>
		<tbody>
			<?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $count_movimientos+=1?>
			<tr>
				<td> 
					<b><?php echo e($count_movimientos); ?></b>. <?php echo e($movimiento->created_at); ?>

				</td>
				<td>
					<?php if(starts_with($movimiento->movimiento->description, 'Venta Realizada')): ?>
					<?php $__currentLoopData = $movimiento->movimiento->venta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento->movimiento->venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<strong>Artículo: </strong><?php echo e($movimiento->movimiento->venta->articulo->name); ?> | <?php echo e($movimiento->movimiento->venta->articulo->pertenece_category->category); ?> (<?php echo e($movimiento->movimiento->venta->articulo->email); ?>)
					<br>
					<strong>Costo: </strong><?php echo e($movimiento->movimiento->venta->articulo->costo); ?> $
					<br>
					<strong>Cliente: </strong><?php echo e($movimiento->movimiento->venta->cliente->name); ?> <?php echo e($movimiento->movimiento->venta->cliente->lastname); ?>

					<?php break;?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					NO APLICA
					<?php endif; ?>
					<br>
					NOTA: <b><?php echo e($movimiento->movimiento->note_movimiento); ?> </b>
				</td>
				<td>
					<strong>Entidad: </strong><?php echo e($movimiento->movimiento->entidad); ?>

					<br>
					<strong>Cantidad: </strong><?php echo e($movimiento->movimiento->cantidad); ?>

				</td>
				<td>
					<?php if($movimiento->movimiento->type == 'bums'): ?>
					<?php 
					$transaccion="";
					$contar_x=0;
					$alterno=0;
					?>
					<?php $__currentLoopData = $movimiento->movimiento->usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($x->pivot->porcentaje == 0): ?>
					<?php $alterno++; ?>
					<strong>Venta realizada por: </strong><?php echo e($x->name); ?> <?php echo e($x->lastname); ?> (10% = <?php echo e(number_format(((10 / 100) *  $movimiento->movimiento->price), 0, ',', '.')); ?> <?php echo e($movimiento->movimiento->moneda->sign); ?>)

					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<br>
					Acciones
					<br>
					<?php if($movimiento->movimiento->type == 'bums'): ?>
					<?php 
					$transaccion="";
					$contar_x=0;
					?>
					<?php $__currentLoopData = $movimiento->movimiento->usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($x->pivot->porcentaje != 0): ?>
					<?php if($alterno == 0): ?>
					<strong>Dueño:</strong> (<?php echo e($x->name); ?> <?php echo e($x->lastname); ?>) | <?php echo e(number_format((($x->pivot->porcentaje / 100) *  $movimiento->movimiento->price), 0, ',', '.')); ?> <?php echo e($movimiento->movimiento->moneda->sign); ?> (<?php echo e($x->pivot->porcentaje); ?>%)
					<br>
					<?php else: ?>
					
					
					<strong>Dueño:</strong> (<?php echo e($x->name); ?> <?php echo e($x->lastname); ?>) | <?php echo e(number_format((($x->pivot->porcentaje / 100) * ( $movimiento->movimiento->price - ($movimiento->movimiento->price * 0.10 ))), 0, ',', '.')); ?> <?php echo e($movimiento->movimiento->moneda->sign); ?> (<?php echo e($x->pivot->porcentaje); ?>%)
					<br>
					<?php endif; ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</td>
				<td>
					<strong>Precio de venta: </strong> <?php echo e(number_format($movimiento->movimiento->price * $movimiento->movimiento->cantidad, 0, ',', '.')." ".$movimiento->movimiento->moneda->sign); ?>

					<br>
					<strong>Precio del dolar del día: </strong><?php echo e(number_format($movimiento->movimiento->dolardia, 0, ',', '.')); ?> Bs
					<br>
					<b>Precio de venta ($): </b><?php echo e(number_format(($movimiento->movimiento->price / $movimiento->movimiento->moneda->valor), 2, ',', '.')); ?> $
					<br>
					<b>Ganancia neta ($)</b>: <?php echo e(number_format(($movimiento->movimiento->price / $movimiento->movimiento->moneda->valor) - $movimiento->movimiento->venta->articulo->costo, 2, ',', '.')); ?> $

					<?php $ganancia_neta+= ($movimiento->movimiento->price / $movimiento->movimiento->moneda->valor) - $movimiento->movimiento->venta->articulo->costo ?>
					
				</td>
			</tr>
			<?php $alterno=0; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<br>
	<h1>Ganancia neta total de la empresa: <?php echo e(number_format($ganancia_neta, 2, ',', '.')); ?> $</h1>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>