<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width"/>
	<title>BumsGames.com.ve</title>
	<script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
	<script src="//cdn.jsdelivr.net/npm/jquery.marquee@1.5.0/jquery.marquee.min.js" type="text/javascript"></script>
	<script src='<?php echo e(asset("js/jquery.zoom.js")); ?>'></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet"/>
	<link rel="icon" href="img/logo_circular.ico" />
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bums.css')); ?>"/>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<link href="<?php echo e(url('css/bums_v2.css')); ?>"  rel="stylesheet"/>
	<script async custom-element="amp-auto-ads"
	src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js">
</script>




</head>

<body style="background-color: white;">
	<div class="bg-image">
	</div>
	<div class="layer">
		
		<nav id="mainnavbar" style="background: white !important;" class="navbar navbar-expand-xl navbar-light bg-light menu navBums fixed-top">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation" style="background: white;">
				<span class="navbar-toggler-icon"></span>
			</button>
			<a class="navbar-brand" href="/">
				<img alt="Brand" src="<?php echo e(url('img/lo2.png')); ?>" width="160">
			</a>
			<div class="collapse navbar-collapse" id="navbarTogglerDemo01">
				<br>
				<div class="row">
					
				</div>
				<ul id="searchnav" class="navbar-nav mr-auto">
					<li>		
						<form class="form-inline" action="/buscar_articulo_bums" method="get">
							<div id="searchnavgroup" class="input-group">
								<input autocomplete="off" type="text" class="form-control" id="exampleInputEmail1" name="name" placeholder="Simplifica tu compra utilizando el buscador.">

								<div class="input-group-append">
									<button id="searchbtn" class="btn btn-danger btnbuscar"><i class="fa fa-search" aria-hidden="true"></i> Buscar</button>
								</div>
							</div>
						</form>
					</li>
				</ul>

				<ul class="navbar-nav ml-auto menubuttons">
					<li class="nav-item active">
						<div class="dropdown">
							<strong><a class="nav-link dropbtn" id="category_btn" style="background-color: rgba(170, 170, 170, 1); color: white;"><i id="down_icon" class="fas fa-chevron-down"></i> CATEGORIAS</a></strong>
						</div>
					</li>

					
					<li class="nav-item menunav active">
						<a class="nav-link" id="login_us" href="/ayuda"><i class="fa fa-users" aria-hidden="true" title="texto al pasar el raton"></i> AYUDA</a>
					</li>
					<?php if(Auth::guard('client')->guest()): ?>
					<li class="nav-item menunav active">
						<strong>
							<button style="border:none" type="button" class="btn btn-primary nav-link" id="login_us" data-toggle="modal" data-target="#modalregistro">
								<i class="fa fa-user-circle" aria-hidden="true"></i> REGISTRARSE
							</button>
						</strong>
					</li>
					<?php endif; ?>
					<?php if(Auth::guard('client')->guest()): ?>
					<li class="nav-item menunav active">	
						<a class="nav-link " href="/login" id="login_us"><i class="fas fa-user"></i> INICIAR SESION</a>
					</li>
					<?php endif; ?>
					<?php if(Auth::guard('client')->check()): ?>
					<li class="nav-item menunav active dropicon casolog">
						<a class="nav-link " href="/adminpaneluser" id="login_us"><i class="fa fa-user-circle-o dropbtn" style="padding:0" aria-hidden="true"></i> MI CUENTA</a>
						<div class="dropdown-content">
							<a href="/adminpaneluser">Panel Personal</a>
							<a href="/logout_user">Cerrar Sesion</a>

						</div>
					</li>
					<li style="display:none" class="nav-item menunav active casolog">
						<a class="nav-link " href="/adminpaneluser" id="login_us"><i class="fa fa-user-circle-o dropbtn" style="padding:0" aria-hidden="true"></i> PANEL PERSONAL</a>
					</li>
					<li style="display:none" class="nav-item menunav active casolog">
						<a class="nav-link " href="/logout_user" id="login_us"><i class="fa fa-user-circle-o dropbtn" style="padding:0" aria-hidden="true"></i> CERRAR SESION</a>
					</li>
					<?php endif; ?>		

					
					
					<li class="nav-item menunav active">	
						<label class="menu car" for="check"><i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> <span class="badge badge-light rojoBlanco" id="badge"><?php echo e(count(Session::get('carrito'))); ?></span>	</label>
					</li>
				</ul>

			</div>
		</nav>

	<style type="text/css">
		.area_foto{
			width: 250px;
			height: 150px;
		}
	</style>
	

	<div class="dropdown-content2" id="dropdown-content2">
		<div class="tile_3">
			<center>
				<h1 class="background_categoria">CATEGORIAS</h1>
				<input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">
				<div class="padre">
					<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<form action="articulos" @method('POST') name="formulario_category">
						<a href="#" class="submit-link" >
							<input type="text" name="category" hidden="" value="<?php echo e($categoria->id); ?>">
							<div class="area_categoria">
								<div class="area_foto">
									<center>
										<img class="img_category" src="<?php echo e(url('img/'.$categoria->image)); ?>" alt="">
									</center>
								</div>
								<div class="categoria_padding">
									<h6>
										<?php echo e($categoria->category); ?>

									</h6>
									<hr class="hr_black">	
									<p><?php echo e($categoria->description); ?></p>
								</div>
							</div>
						</a>
					</form>	
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</center>
		</div>

			
		</div>

		

		<div class="dropdown-content">
			
		</style>
		<div class="area_categoria">
			<center>
				<div class="margen_top">
					<img src="img/logops.png" width="50" alt="">
					<h2>
						PS4 PRIMARIO
					</h2>
					<p>Juego digital que juegas de cualquier usuario y no necesitas internet para jugar.</p>
				</div>
			</center>
		</div>

			
		</div>

		<nav class="navbar navbar-expand-lg navbar-light bg-light menu navBums fixed-top" hidden="">

			<div class="collapse navbar-collapse" id="navbarNavDropdown">
				<a class="navbar-brand" href="/">

					<img alt="Brand" src="<?php echo e(url('img/logobums2.png')); ?>" width="150">

				</a>
			</div>

			<form class="form-inline" action="/buscar_articulo_bums" method="get">
				<input class="form-control buscador_bums" name="name" type="search" placeholder="Buscar articulo" aria-label="Search" autocomplete="off">
				<button class="btn btn-outline-success my-2 my-sm-0 boton botonBuscador_bums"  type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
			</form>
			<div class="collapse navbar-collapse" id="navbarNavDropdown">
				<ul class="navbar-nav ml-auto">

					<li class="nav-item active">
						<strong><a class="nav-link a_Bums" href="/ayuda"><i class="fa fa-users" aria-hidden="true"></i> AYUDA</a></strong>
					</li>
					
					
				</ul>		
			</div>
		</nav>

		<ul class="nav justify-content-center ulBums1 navNormal	" style="background-color: black !important; padding: 5px;">

			<li class="nav-item">
				<a class="nav-link letraBlanca" href="lista_escrita">LISTA ESCRITA</a>
			</li>
			<li class="nav-item marcaOferta">
				<a class="nav-link letraBlanca" href="/articulos_oferta">OFERTAS</a>
			</li>
			<li class="nav-item">
				<a class="nav-link letraBlanca" href="/articulos_web">ARTICULOS RECIENTES</a>
			</li>
			<!-- <li class="nav-item">
				<a class="nav-link letraBlanca" href="/agotados">ARTICULOS AGOTADOS</a>
			</li> -->
			<li>
				<span class="nav-link letraBlanca">Cambia tu moneda <span class="fa fa-arrow-right"></span> </span>
			</li>
			<li>
				<form class="form-inline margin" action="<?php echo e(url('prueba')); ?>" method="get">
					
					<select class="form-control selectCoin" onchange="this.form.submit()" name="id_coin" id="id_coin">
						<option class="form-control" selected="" value="<?php echo e($moneda_actual->id); ?>"><?php echo e($moneda_actual->coin); ?></option>
						<?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option class="form-control" value="<?php echo e($coin->id); ?>"><?php echo e($coin->coin); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					&nbsp;
					&nbsp;&nbsp;
					<img id="my_image" src="<?php echo e(url('img/'.$moneda_actual->imagen)); ?>" alt="" width="60">
				</form>
			</li>
		</ul>
		<amp-auto-ads type="adsense"
		data-ad-client="ca-pub-2298464716816209">
	</amp-auto-ads>



	<?php echo $__env->make('modal.contacto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('modal.comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<button type="button" class="btn btn-primary contactbutton" data-toggle="modal" data-target="#contactModal">
		Contáctanos <i class="fab fa-whatsapp fa-lg align-middle float-right"></i>
	</button>
	<button type="button" class="btn btn-primary commentbutton" data-toggle="modal" data-target="#commentModal">
			DEJANOS TU COMENTARIO <i class="far fa-lg fa-comment-dots float-right align-middle"></i>	
	</button>
	<input type="checkbox" class="checkbox" id="check">


	<div class="carrito_compra" style="overflow-y: auto;" >
		<div style="margin-top: 115px;">			
			<h1 class="titulo-carrito"><i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i>	CARRITO DE COMPRAS</h1>	

			<div class="container contcarrito" style="color: black;">	
				<br>	
				<table class="table table-hover" >
					<tbody id="tablaCarrito">
						<?php $i = 1; ?>
						<?php $precio = 0; ?>
						<?php if(Session::has('carrito')): ?>


						<?php $__currentLoopData = Session::get('carrito'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th>
								<?php echo $i++; ?>
							</th>
							<td>
								<input autocomplete="off" type='text' class='id_articulo' value='<?php echo e($x['id']); ?>' hidden="">
								<?php echo e($x['articulo']); ?> || <?php echo e($x['categoria']); ?>

							</td>
							<td>
								<?php echo e(number_format($x['precio'] * $moneda_actual->valor, 2, ',', '.')); ?> <?php echo e($moneda_actual->sign); ?>

								<?php $precio += $x['precio']; ?>
							</td>
							<td>
								<img src="img/<?php echo e($x['imagen']); ?>" width="40" height="45" alt="">

							</td>
							<td>
								<button type="button" class="close" onclick="borrarElementoCarrito(<?php echo e($i - 1); ?>, <?php echo e($moneda_actual->valor); ?>, '<?php echo e($moneda_actual->sign); ?>');">
									<span aria-hidden="true">&times;</span>
								</button>
							</td>

						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php endif; ?>
						<tr>
							<td>	
							</td>
							<td>	
							</td>

							<td>
								<strong>Total:<br> <?php echo e(number_format($precio * $moneda_actual->valor, 2, ',', '.')); ?> <?php echo e($moneda_actual->sign); ?></strong>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<br>	
			<input type="number" id="nArt" value="<?php echo e($i - 1); ?>" hidden="">
			<div class="modal-footer">
				<button type="button" id="cerrarCarro" class="btn btn-secondary"><i class="fa fa-chevron-right" aria-hidden="true"></i> Cerrar</button>
				<button id="comprarCarrito" class="btn btn-danger"><i class="fas fa-cash-register"></i> Comprar</button>
			</div>
		</div>
	</div>
	<?php echo $__env->yieldContent('ultimos-vendidos'); ?>
	
	<?php echo $__env->yieldContent('content'); ?>
	

	<div class="bumscontent">
		<div style="background:rgba(0,0,0,0.5)">
			<?php echo $__env->yieldContent('comment'); ?>
		</div>
	</div>


	<script>
		function cerrarCarro(){
			$('.menu.car').trigger('click');
		};
		$("#cerrarCarro").click(cerrarCarro);
	</script>

	<?php echo $__env->make('modal.carrito', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<!-- INICIO FOOTER -->
<footer class="page-footer font-small cyan darken-3 foot1">
	<div class="container">
		<br>
		<br>
		<div class="row">

			<div class="col-2">

				<a class="navbar-brand" href="/">
					<img alt="Brand" src="<?php echo e(url('img/lo2.png')); ?>" width="160">
				</a>
			</div>
			<div class="col escondite">
				<div class="cartica">
					<center style="padding: 10px;"><h5>DIRECCION</h5></center>
					<hr>	
					<center>
						<img src="img/pelota.png" width="150" alt="Avatar">
						<br>
						<br>	
						PUERTO ORDAZ, Estado Bolivar <br>	
						C.C. Alta Vista II, segundo Piso <br>
						Local #22 frente a la Sala de Juegos <br>	
						<br>	
					</center>	
				</div>
			</div>
			<div class="col escondite">
				<div class="cartica">
					<center style="padding: 10px;"><h5>REDES SOCIALES</h5></center>
					<hr>	
					<center>	
						<a href="https://www.facebook.com/bumsgamesoficial" target="_blank" title="Vista nuestro facebook, que esperas?"><img src="img/logo-f.png" class="abc" alt=""> @BumsGames</a>
						<br>
						<br>
						<a href="https://www.instagram.com/bumsgames/" target="_blank" href="www.google.co.ve" title="Unete a nuestra comunidad en Instagram, tenemos muchas sorpresas"><img class="abc" src="img/logo-i.png" alt=""> @BumsGames</a>
						<br>
						<br>
						<a href="https://perfil.mercadolibre.com.ve/BUMSGAMES_OFICIAL" target="_blank" title="Mira nuestra reputacion en MercadoLibre, somos MercadoLideres"><img class="abc2" src="img/logo-m.png" alt=""> BumsGames_OFICIAL</a>
					</center>


					<br>
				</div>
			</div>
			<div class="col escondite">
				<div class="cartica">
					<center style="padding: 10px;"><h5>CONTACTANOS</h5>
						<hr>	
						David Salazar.
						<br>	
						<i class="fab fa-whatsapp fa-2x"></i> 
						(+58) 0414-987-50-29

						<br>
						<br>			
						Genesis Moreno.
						<br>	
						<i class="fab fa-whatsapp fa-2x"></i> 
						(+58) 0412-796-43-49
						<br>	
						<br>	
						Daniel Duarte.
						<br>	
						<i class="fab fa-whatsapp fa-2x"></i> 
						(+58) 0412-119-23-79
						<br>	
						<br>
					</center>
				</div>
			</div>
		</div>
		<br>	
		
		<div class="footer-copyright text-center py-3 foot2">Llegamos para hacer la diferencia.
			<a href="https://mdbootstrap.com/bootstrap-tutorial/"> BumsGames.com.ve</a>
		</div>
	</footer>
	<!-- FIN FOOTER -->
	<?php echo $__env->make('modal.registrarse', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
	


	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="<?php echo e(url('js/bums.js')); ?>"></script>
	<script src="<?php echo e(url('js/bums_v2.js')); ?>"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

	<script>
		var margen_carrito = $(".carrito_compra").outerWidth(true) - $(".carrito_compra").outerWidth();
		$( ".checkbox").change(function(e) {
			if($(".checkbox").is(":checked")){
				goRight();
			}
			else{
				goLeft();
			}
		});


		function goRight(){ // inner stuff slides left
			var initalLeftMargin = $( ".carrito_compra" ).css('margin-left').replace("px", "")*1;
			var newLeftMargin = (initalLeftMargin - margen_carrito); // extra 2 for border
			$( ".carrito_compra" ).animate({marginLeft: newLeftMargin}, 500);
		}
		function goLeft(){ // inner stuff slides right
			var initalLeftMargin = $( ".carrito_compra" ).css('margin-left').replace("px", "")*1;
			var newLeftMargin = (initalLeftMargin + margen_carrito); // extra 2 for border
			$( ".carrito_compra" ).animate({marginLeft: newLeftMargin}, 500);
		}

		$('form .submit-link').on({
		    click: function (event) {
		        event.preventDefault();
		        $(this).closest('form').submit();
		    }
		});
	</script>

	<!-- Footer -->

</body>






</html>