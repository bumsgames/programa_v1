<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> <?php echo e($title); ?></h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<h6>Numero de Noticias: <?php echo e($noticias->total()); ?></h6>
				
				<div class="table-responsive">
				
					<table class="table">
						<thead>
							<tr>
                                <th scope="col">#</th>
								<th scope="col">Título</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Prioridad</th>
								<th scope="col"># de Likes</th>
                                <th scope="col">Imagen</th>
                                <th scope="col">Autor</th>
                                <th></th>
							</tr>
						</thead>
						<tbody>	
                            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="align-middle"><?php echo e($noticia->id); ?></td>
                                <td class="align-middle"><?php echo e($noticia->titulo); ?></td>
                                <td class="align-middle"><?php echo e($noticia->descripcion); ?></td>
                                <td class="align-middle"><?php echo e($noticia->prioridad); ?></td>
                                <td class="align-middle"><?php echo e($noticia->likes); ?></td>
                                <td class="align-middle" style="width:25%"><img width="100%" src="<?php echo e(asset('img/'.$noticia->imagen)); ?>" alt="No se encontro la imagen"></td>
                                <td class="align-middle"><?php echo e($noticia->autor->name); ?> <?php echo e($noticia->autor->lastname); ?></td>
                                <td class="align-middle">
                                    <a href="/noticias/editar/<?php echo e($noticia->id); ?>" class="btn btn-info">Editar</a> 
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#eliminarmodal" id="modaltrigger" onclick="modaltrigger(<?php echo e($noticia->id); ?>,'<?php echo e($noticia->titulo); ?>')">
                                        Eliminar
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            </tbody>
		            </table>
	            </div>
	<?php if($noticias->hasPages()): ?>
        <ul class="pagination justify-content-center">
            
            <?php if($noticias->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link"><</span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($noticias->previousPageUrl()); ?>" rel="prev"><</a></li>
            <?php endif; ?>

            <?php if($noticias->currentPage() > 3): ?>
                <li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($noticias->url(1)); ?>">1</a></li>
            <?php endif; ?>
            <?php if($noticias->currentPage() > 4): ?>
                <li class="page-item"><span class="page-link">...</span></li>
            <?php endif; ?>
            <?php $__currentLoopData = range(1, $noticias->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i >= $noticias->currentPage() - 2 && $i <= $noticias->currentPage() + 2): ?>
                    <?php if($i == $noticias->currentPage()): ?>
                        <li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link" href="<?php echo e($noticias->url($i)); ?>"><?php echo e($i); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($noticias->currentPage() < $noticias->lastPage() - 3): ?>
                <li class="page-item"><span class="page-link">...</span></li>
            <?php endif; ?>
            <?php if($noticias->currentPage() < $noticias->lastPage() - 2): ?>
                <li class="page-item hidden-xs"><a class="page-link" href="<?php echo e($noticias->url($noticias->lastPage())); ?>"><?php echo e($noticias->lastPage()); ?></a></li>
            <?php endif; ?>

            
            <?php if($noticias->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($noticias->nextPageUrl()); ?>" rel="next">></a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link">></span></li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>


</div>

</div>
</div>

</main>
<!-- Modal -->
<div class="modal fade" id="eliminarmodal" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Eliminar: <span class="titulomodal"></span></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <p>Estas seguro que deseas eliminar la noticia "<strong><span class="titulomodal"></span></strong>"?</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <a href="" id="delete-link" class="btn btn-danger">Eliminar</a>
            </div>
        </div>
    </div>
</div>
<script src="http://127.0.0.1:8000/js/jquery3.min.js"></script>
<script>
    $('#exampleModal').on('show.bs.modal', event => {
        var button = $(event.relatedTarget);
        var modal = $(this);        
    });
    
    function modaltrigger(id, titulo){
        $('.titulomodal').text(titulo);
        $('#delete-link').attr("href","/noticias/eliminar/"+id);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>