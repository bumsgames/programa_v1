<?php $__env->startSection('content'); ?>`
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i>Categoria de articulos</h1>
			<p>Llegamos para hacer la diferencia</p>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<div style="overflow-x:scroll" class="row">
					<div class="col">
						<h4>Articulos disponibles</h4>
						<br>	
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<h6><?php echo e($category->category); ?></h6>
						<button class="btn btn-primary" onclick="location.href='<?php echo e(url('categoria_art/'.$category->id)); ?>';"><?php echo e($category->category); ?></button>
						<br>	
						<br>
						<br>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="col">
						<h4>Articulos Agotados</h4>
						<br>	
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<h6><?php echo e($category->category); ?></h6>
						<button class="btn btn-secondary" onclick="location.href='<?php echo e(url('categoria_artOff/'.$category->id)); ?>';"><?php echo e($category->category); ?></button>
						<br>	
						<br>
						<br>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>