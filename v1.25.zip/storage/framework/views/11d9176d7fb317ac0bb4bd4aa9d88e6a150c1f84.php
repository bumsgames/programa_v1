<div class="hijo contenedor cat_<?php echo e($articulo->category); ?>">
	<style>	
	.contenedor:hover .imagen {-webkit-transform:scale(1.1);transform:scale(1.1); transition: all 0.3s ease-in-out;}
	.contenedor {overflow:hidden;}
</style>


<div class="card cartaInicio" style="overflow:hidden">
	
		
		
	<center>
		<div class="espaciom_img" style="">
		    <form class="" action="ver_mas" method="POST">
			<button style="width:100%;border:none;background-color:unset;padding:0;cursor:pointer;text-align:unset" type="submit" name="art_id" value="<?php echo e($articulo->id); ?>">
				<div class="content_fondo img_centro" style="background-color: white;" style="">
                        <td><img class="img-top" src="<?php echo e(url('img/'.$articulo->fondo)); ?>" alt="Card image cap" style=""></td>
				</div>
			</button>
		    </form>
		</div>
	</center>


	<?php if($articulo->oferta > 0): ?>
	
	<div class="cartaEtiqueta_oferta">
		<img  src="<?php echo e(url('img/oferta.png')); ?>" alt="" class="oferta-img">
	</div>
	<?php endif; ?>

	<!-- <div class="cartaFoto_pequena"> 
			<img class="portada_articulo" src="<?php echo e(url('img/'.$articulo->image)); ?>"> 
		</div>  -->
		<div class="card-body letraNegra" style="background-color: rgba(220, 220, 220, 1);">
			<form class="" action="ver_mas" method="POST">
				<button style="border:none;background-color:unset;padding:0;cursor:pointer;text-align:unset" type="submit" name="art_id" value="<?php echo e($articulo->id); ?>">
					<div class="titulo_carta">
						<strong><?php echo e($articulo->name); ?></strong>
					</div>
					<br>
					<b style="font-size: 12px;">Condicion: </b>
				</button>
				<strong><p style='font-size: 13px;'><?php echo e($articulo->pertenece_category->category); ?></p></strong>		
				<?php if($articulo->category == 4 || $articulo->category == 6 || $articulo->category == 11 || $articulo->category >= 14): ?>	
				<p style='font-size:12px'>Envios al siguiente dia habil luego del pago.</p>
				<?php else: ?>
				<p style='font-size:12px;'>Peso: <?php echo e($articulo->peso); ?>GB</p>
				<?php endif; ?>
			
			</form>
		</div>

		<div class="lightgray" style="background: #F1948A;">
			<div class="row nose">
				<div class="col">
					<button class="btn btn-primary btn-block botonCarta"
					onclick="agregaCarro('<?php echo e($articulo->id); ?>', '<?php echo e($articulo->name); ?>', 
						'<?php echo e($articulo->pertenece_category->category); ?>', 
						<?php echo e($articulo->price_in_dolar); ?>,
						'<?php echo e($articulo->fondo); ?>', <?php echo e($moneda_actual->valor); ?>, '<?php echo e($moneda_actual->sign); ?>');">
						<i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> 
					</button>
				</div>
				<div style='font-size: 11px;' class="col-8 cartaCifra mt-1 mb-1">
					<?php if($articulo->oferta==1): ?> 
					<del> 
						<strong class="precio_rebajado">
							<?php echo e(number_format($articulo->offer_price * $moneda_actual->valor, 2, ',', '.')); ?> <?php echo e($moneda_actual->sign); ?>

						</strong>
					</del> 
					<?php endif; ?>
					&nbsp;<strong> <?php echo e(number_format($articulo->price_in_dolar * $moneda_actual->valor, 2, ',', '.')); ?> <?php echo e($moneda_actual->sign); ?> </strong>
				</div>
			</div>
		</div>
	</div>
</div>