<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Prueba</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"/>
</head>
<body>
	<div class="container">
		<h1>LISTA DE ARTICULOS DISPONIBLES DE: <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></h1>
		<?php $i = 1; ?>
		<?php $categoria = ''; ?>
		<div class="row">
			<div class="col">
				<?php $cuenta = 0; ?>
				<?php $__currentLoopData = $articles_mios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $articles_mios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(($articulo->id != $articulo2->id) && ($articulo->name == $articulo2->name) && ($articulo->porcentaje == $articulo2->porcentaje) && ($articulo->category == $articulo2->category)): ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $articles_mios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($articulo->pertenece_category->category != $categoria): ?>
				<?php $categoria = $articulo->pertenece_category->category; ?>
				<?php $i = 1; ?>
				<br>
				<br>
				<h4><strong><?php echo e($categoria); ?></strong></h4>
				<br>
				<br>
				<?php endif; ?>

				<strong><?php echo $i++; ?></strong>. <?php echo e($articulo->name); ?>. Cantidad: <strong><?php echo e($articulo->total); ?></strong>. Acción: <strong><?php echo e($articulo->porcentaje); ?>%</strong>,
				<strong> <?php echo e(number_format((($articulo->price_in_dolar)*$articulo->total*$articulo->porcentaje/100 )	, 2, ',', '.')); ?> $</strong>	
				<br><br>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php $__currentLoopData = $articles_price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $cuenta += $aprice->price_in_dolar*$aprice->porcentaje/100; ?>	    
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
 
		</div>
		<br>
		<br>
		<h3>
			Articulos disponibles: <?php echo e($articles_price->count()); ?>

			<br>
			Valor en Articulos de <?php echo e($user->name); ?> <?php echo e($user->lastname); ?>: <?php echo e(number_format((($cuenta) )	, 2, ',', '.')); ?> $
			<br>
			<br>

		</h3>
	</div>

</body>
</html>