<div class="modal fade letraNegra" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document" >
		<div class="modal-content" >
			<div class="modal-header" >
				<h3 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> Carrito de compras</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<table class="table table-hover" id="tablaCarrito">
					<tbody>
						<?php $i = 1; ?>
						<?php $precio = 0; ?>
						<?php if(Session::has('carrito')): ?>


						<?php $__currentLoopData = Session::get('carrito'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th>
								<?php echo $i++; ?>
							</th>
							<td>
								<input type='text' class='id_articulo' value='<?php echo e($x['id']); ?>' hidden="">
								<?php echo e($x['articulo']); ?> || <?php echo e($x['categoria']); ?>

							</td>
							<td>
								<?php echo e(number_format($x['precio'] * $moneda_actual->valor, 2, ',', '')); ?> <?php echo e($moneda_actual->sign); ?>

								<?php $precio += $x['precio']; ?>
							</td>
							<td>
								<img src="img/<?php echo e($x['imagen']); ?>" width="40" height="45" alt="">

							</td>
							<td>
								<button type="button" class="close" onclick="borrarElementoCarrito(<?php echo e($i - 1); ?>, <?php echo e($moneda_actual->valor); ?>, '<?php echo e($moneda_actual->sign); ?>');">
									<span aria-hidden="true">&times;</span>
								</button>
							</td>

						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php endif; ?>
						<tr>
							<td>
								<strong>Total: <?php echo e(number_format($precio * $moneda_actual->valor, 2, ',', '')); ?> <?php echo e($moneda_actual->sign); ?></strong>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<input type="number" id="nArt" value="<?php echo e($i - 1); ?>" hidden="">
			<div class="modal-footer">
				<button id="comprarCarrito" class="btn btn-danger"><i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> Comprar</button>
			</div>
		</div>
	</div>
</div>