<?php $__env->startSection('content'); ?>
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> <?php echo e($title); ?></h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
                <div class="tile">
                        <h6>Numero de articulos: <?php echo e($articles_cantidad); ?></h6>

            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre del Articulo</th>
                        <th>Categoria del Articulo</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td scope="row"><?php echo e($article->id); ?></td>
                        <td><?php echo e($article->name); ?></td>
                        <td><?php echo e($article->pertenece_category->category); ?></td>
                        <td>
                            <form action="/actualizarImagen/<?php echo e($article->id); ?>" method="post" enctype="multipart/form-data">
                                <input name="_token" id="token" value="<?php echo e(csrf_token()); ?>" hidden="">

                                <div class="custom-file">
                                    <input name="image" id="inputFile2" type="file" class="custom-file-input" lang="es" required>
                                    <label class="custom-file-label" for="customFileLang">Seleccionar Archivo</label>
                                    <input hidden="" name="image" id="inputFiletext" type="text" class="custom-file-input" lang="es">
                                </div>
                                <button class="btn btn-primary mt-2 float-right" type="submit">Actualizar Imagen</button>
                            </form>
                            <div style="text-align:center;">
                                    <img id="img2" width="175">
                                </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center"><strong><h5>No hay productos sin imagen</h5></strong></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
                </div>
	    </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bums', ['tutoriales' => $tutoriales], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>