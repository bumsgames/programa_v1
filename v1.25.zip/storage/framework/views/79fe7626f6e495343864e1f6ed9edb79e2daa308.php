<div class="modal fade" id="commentModal">
  <div class="modal-dialog  modal-lg">
    <div class="modal-content">
      <div class="modal-header headerComment">
        <h3 class="commentTitle"> Tu opinion vale mucho para nosotros</h3>

      </div>
      <div class="modal-body bodyComment" id='comentariosmodal'>
        <h5>Tu comentario sera mostrado una vez sea aprobado!</h5>
        <?php echo Form::open(['action' => 'CommentController@store', 'method' => 'POST']); ?>

        <?php if(Auth::guard('client')->check()): ?>
        <div class="form-check-inline">
        <label class="form-check-label">
          <?php echo e(Form::radio('opcion', '1',true),['class'=>'form-check-input']); ?>

          Publicar con mi nombre
          </label>
        </div>
        <div class="form-check-inline">
        <label class="form-check-label">
          <?php echo e(Form::radio('opcion', '2'),['class'=>'form-check-input']); ?>

          Publicar como anonimo
          </label>
        </div>
        <?php endif; ?>
        <br>
        <?php if(Auth::guard('client')->guest()): ?>

        <div class="form-group">
          
          <?php echo e(Form::label('nombre','Escribe el nombre a mostrar (Dejalo vacio para comentar como anonimo)')); ?>  
          <?php echo e(Form::text('nombre','',['class'=>'form-control','placeholder'=>'Nombre','autocomplete'=>'off'])); ?>

        </div>
        <?php endif; ?>
        <div class="form-group">
        <?php echo e(Form::label('comentario','Dejanos tu comentario y sera mostrado una vez sea aprobado')); ?>  
          <?php echo e(Form::textarea('comentario','',['class'=>'form-control','placeholder'=>'Deja tu comentario...'])); ?>

        </div>
        <?php echo e(Form::submit('Enviar comentario',['class'=>'btn btn-primary btnmodal','id'=>'idcomentariobtn'])); ?>

        <?php echo Form::close(); ?>

    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger btnmodal" data-dismiss="modal">Cerrar</button>
      </div>

    </div>
  </div>
</div>

<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>

<?php if(session()->has('errormessage')): ?>
    <div class="alert alert-warning">
        <?php echo e(session()->get('errormessage')); ?>

    </div>
<?php endif; ?>