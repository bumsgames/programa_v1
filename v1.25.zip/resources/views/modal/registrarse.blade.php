
	<!-- Modal -->
	<div class="modal fade" id="modalregistro" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <a href="#" data-dismiss="modal">
                <div class="modal-content" style="border-radius:5px">
                    <div class="modal-body">
                        <h5><strong>En estos momentos los agentes BumsGames crean las cuentas de los usuario luego de la primera compra</strong></h5>
                    </div>
                </div>
            </a>
        </div>
	</div>

    