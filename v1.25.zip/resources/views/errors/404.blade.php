@extends('layouts.plantillaWeb')
@section('content')

    <div class="container page404">
        <div class="row">
            <div class="col-12">
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <center>
                    <h1 class="display-1">404</h1>
                    <h1>PAGINA NO ENCONTRADA</h1>
                </center>
            </div>
        </div>
    </div>
    
@endsection