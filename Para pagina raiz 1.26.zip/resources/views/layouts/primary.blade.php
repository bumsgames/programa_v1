@yield('content')
<h1>Este es mi yield</h1>
