<?php

namespace Bumsgames;

use Illuminate\Database\Eloquent\Model;

class Visita extends Model
{
    protected $fillable = [
        'tipo'
    ];
}
