<?php

namespace Bumsgames;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    //
}
