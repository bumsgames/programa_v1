@extends('layouts.bums')

@section('content')
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> {{ $title }} </h1>
		</div>
		<ul class="app-breadcrumb breadcrumb">
			<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
			<li class="breadcrumb-item"><a href="#">{{ $title }}</a></li>
		</ul>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">

				@include('form_busqueda_venta')
				<br>	
				<input type="text" placeholder="Buscar" class="form-control" id="buscador">
				<br>
				<br>
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Vendedor</th>
								<th scope="col">Articulo</th>
								<th scope="col">Cliente</th>
								<th scope="col">Fecha</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=1; ?>
							@foreach($sales as $sale)
							<tr>	
								<td><?php echo $i++; ?> </td>
								<td>	
									<strong>	Vendedor: </strong>
									{{ $sale->user->name }}
									{{ $sale->user->lastname }}
								</td>
								<td>	
									<strong>Articulo: </strong>
									{{ $sale->articulo->name }}
									<br>	
									<br>	
									<strong>Categoria: </strong>{{ $sale->articulo->pertenece_category->category }}
								</td>
								<td>
									<strong>	
										Cliente:
									</strong>
									{{ $sale->cliente->name }}	{{ $sale->cliente->lastname }}	
									<br>	
									<br>	
									<strong>Pago: </strong>{{ number_format($sale->movimiento->price, 0, ',', '.') }} |
									{{ $sale->movimiento->moneda->coin }} | {{ $sale->movimiento->entidad }}
								</td>
								<td>
									<strong>	
										Fecha:
									</strong>
									{{ $sale->created_at->format('d M Y ')}}
									{{-- {{ $sale->created_at->format("Y-m-d")}} --}}
									<br>
									<br>
									{{ $sale->created_at->diffForHumans() }}
									
								</td>
								<td>
									<button type="button" 
									class="btn btn-secondary" 
									data-toggle="modal" data-target="" Onclick="ventaDirect();">Eliminar</button>
								    </button>
								</td>
							</tr>
							@endforeach
							

						</tbody>
					</table>
				</div>


			</div>

		</div>
	</div>

</main>

@endsection