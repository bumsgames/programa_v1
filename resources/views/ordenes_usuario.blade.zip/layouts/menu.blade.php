@extends('layouts.bums')

@section('content')
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i>Menu principal</h1>
      <p>Llegamos para hacer la diferencia</p>
    </div>
{{--     <ul class="app-breadcrumb breadcrumb">
      <li cla`ss="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="#">Blank Page</a></li>
    </ul> --}}
  </div>
  <div class="row">
    <div class="col">
      <div class="tile">
        <h6>Mejor vendedor del dia</h6>
        <?php $i = 0; ?>
        <?php $contador = 1; ?>
        @foreach($mejor_vendedores_hoy as $vendedor)
        <?php if($contador != $vendedor->ventas){
          $i++;
          $contador = $vendedor->ventas;
        } 
        echo $i;  ?>. {{ $vendedor->name }} {{ $vendedor->lastname }}. Ventas: {{ $vendedor->ventas }}
        <br>
        <br>  
        @endforeach



      </div>
      <div class="tile">
        <h5>Valor de las monedas: </h5>
        <br>  
        @foreach($coins as $coin)
        <h6>{{ $coin->coin }}</h6>
        <form action="cambiar_valor" method="post">
          {{ csrf_field() }}
          <label for="  ">1$ = {{ $coin->valor }} {{ $coin->sign }}</label>
          <br>  
          <input type="text" name="valor" autocomplete="off">
          <button name="id" value="{{ $coin->id }}">Guardar</button>
          <br>  
          <br>  
        </form>
        
        @endforeach


        
      </div>
    </div>
    <div class="col">
      <div class="tile">
        <h6>Mejor vendedor de la semana</h6>
        <?php $i = 0; ?>
        <?php $contador = 1; ?>
        @foreach($mejor_vendedores_semana as $vendedor)
        <?php if($contador != $vendedor->ventas){
          $i++;
          $contador = $vendedor->ventas;
        } 
        echo $i;  ?>. {{ $vendedor->name }} {{ $vendedor->lastname }}. Ventas: {{ $vendedor->ventas }}
        <br>
        <br>  
        @endforeach
      </div>
    </div>
    <div class="col">
      <div class="tile">
        <h6>Articulo mas vendido del dia</h6>
        <?php $i = 0; ?>
        <?php $contador = 1; ?>
        @foreach($articulo_mas_vendido_hoy as $articulo)
        <?php if($contador != $articulo->ventas){
          $i++;
          $contador = $articulo->ventas;
        } 
        echo $i;  ?>. {{ $articulo->name }} || {{ $articulo->category }}. Ventas: {{ $articulo->ventas }}
        <br>
        <br> 
        @endforeach
      </div>
    </div>
    <div class="col">
      <div class="tile">
        <h6>Articulo mas vendido de la semana</h6>
        <?php $i = 0; ?>
        <?php $contador = 1; ?>
        @foreach($articulo_mas_vendido_semana as $articulo)
        <?php if($contador != $articulo->ventas){
          $i++;
          $contador = $articulo->ventas;
        } 
        echo $i;  ?>. {{ $articulo->name }} || {{ $articulo->category }}. Ventas: {{ $articulo->ventas }}
        <br>
        <br>  
        @endforeach
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body" style="word-break: break-all;">
          <div class="row">
            <div class="col">
              <strong>LINKS IMPORTANTES</strong>
              <br>
              <br>

              Chat PlayStation Sony: https://scea.secure.force.com/PreChatEnglishForm/?endpoint=https%3A%2F%2Fscea.secure.force.com%2FLiveChat%2Fapex%2FLiveAgentChat%3Flanguage%3D%23deployment_id%3D572i00000002cba%26org_id%3D00Di0000000H5ef%26button_id%3D573i00000002ftp%26session_id%3D0f4b4af2-9d70-46f1-8ed3-f8a5c264d39a 
              <br>
              <br>
              <br>
              <br>

              Migrar Cuenta Microsoft: https://live.xbox.com/en-US/AccountMigration 
              <br>
              <br>
              <br>
              <br>

              Plus 2 dias: https://www.youtube.com/watch?v=cPvmVizrlNU 
              <br>
              <br>
              <br>
              <br>


              Login Sony: https://id.sonyentertainmentnetwork.com/signin/?client_id=55950157-ae9d-4b10-b0de-94dbef199f2c&scope=openid%2Ckamaji%3Aprivacy_control%2Ckamaji%3Aactivity_feed_get_feed_privacy%2Ckamaji%3Aactivity_feed_set_feed_privacy&state=eyJ0aGVtZSI6ImxpcXVpZCJ9&redirect_uri=https%3A%2F%2Faccount.sonyentertainmentnetwork.com%2Foauth_security_check&response_type=code&prompt=login&ui=pr&noEVBlock=false&error=login_required&error_code=4165&error_description=User+is+not+authenticated#/signin?entry=%2Fsignin
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</main>

@endsection