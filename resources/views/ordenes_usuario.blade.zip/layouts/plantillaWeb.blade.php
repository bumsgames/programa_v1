<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>BumsGames.com.ve</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Do+Hyeon" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontaawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="{{ url('css/bums.css') }}">
	<link rel="icon" href="img/logo_circular.ico" />
	<link rel="stylesheet" href="font.css">
	<link rel="stylesheet" href="main.css">
</head>
<body>
{{-- 	<div class="social-bar">
	<a href="https://www.facebook.com/bumsgamesoficial/" class="icon icon-facebook" target="_blank"></a>
	<a href="https://www.instagram.com/bumsgames/" class="icon icon-instagram" target="_blank"></a>
    <a href="https://www.youtube.com/channel/UC5vd9oCSYHhoPIypaaZb6UQ?view_as=subscriber" class="icon icon-youtube" target="_blank"></a>
</div> --}}
<nav class="navbar navbar-expand-lg navbar-light bg-light menu navBums fixed-top">
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation" style="background: white;">
		<span class="navbar-toggler-icon"></span>
	</button>
	
	<div class="collapse navbar-collapse" id="navbarTogglerDemo01">
		<br>
		<a class="navbar-brand" href="/">
			<img alt="Brand" src="{{ url('img/logobums2.png') }}" width="150">
		</a>
		<br>
		<br>
		<ul class="navbar-nav ml-auto mr-auto">
			<li>		
				<form class="form-inline" action="/buscar_articulo_bums" method="post">
					{{ csrf_field() }}
					<select class="form-control select_bums" name="categoria">
						<option class="form-control optionBuscador" value="0">Todas las categorias</option>
						@foreach($categorias as $categoria)
						<option class="form-control optionBuscador" value="{{ $categoria->id }}">{{ $categoria->category }}</option>
						@endforeach
					</select>
					<input class="form-control buscador_bums" name="name" type="search" placeholder="Buscar articulo" aria-label="Search" autocomplete="off">
					<button class="btn btn-outline-success my-2 my-sm-0 boton botonBuscador_bums"  type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
				</form>
			</li>
		</ul>
		<br>
		<br>
		<ul class="navbar-nav ml-auto">

			<li class="nav-item active">
				<strong><a class="nav-link a_Bums" href="/ayuda"><i class="fa fa-users" aria-hidden="true"></i> AYUDA</a></strong>
			</li>
{{-- 				<li class="nav-item active">
					<strong><a class="nav-link a_Bums" href="" id="login_us"><i class="fa fa-user-circle-o" aria-hidden="true"></i> LOGIN</a></strong>
				</li> --}}
				<li>
					<button class="btn botonCarrito"
					data-toggle="modal" 
					data-target="#exampleModalLong"><i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> <span class="badge badge-light rojoBlanco" id="badge">{{ count(Session::get('carrito')) }}</span></button>
				</li>
			</ul>
		</div>
	</nav>

	<nav class="navbar navbar-expand-lg navbar-light bg-light menu navBums fixed-top" hidden="">

		<div class="collapse navbar-collapse" id="navbarNavDropdown">
			<a class="navbar-brand" href="/">

				<img alt="Brand" src="{{ url('img/logobums2.png') }}" width="150">

			</a>
		</div>
		<form class="form-inline" action="/buscar_articulo_bums" method="post">
			{{ csrf_field() }}
			<select class="form-control select_bums" name="categoria">
				<option class="form-control optionBuscador" value="0">Todas las categorias</option>
				@foreach($categorias as $categoria)
				<option class="form-control optionBuscador" value="{{ $categoria->id }}">{{ $categoria->category }}</option>
				@endforeach
			</select>
			<input class="form-control buscador_bums" name="name" type="search" placeholder="Buscar articulo" aria-label="Search" autocomplete="off">
			<button class="btn btn-outline-success my-2 my-sm-0 boton botonBuscador_bums"  type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
		</form>
		<div class="collapse navbar-collapse" id="navbarNavDropdown">
			<ul class="navbar-nav ml-auto">

				<li class="nav-item active">
					<strong><a class="nav-link a_Bums" href="/ayuda"><i class="fa fa-users" aria-hidden="true"></i> AYUDA</a></strong>
				</li>
{{-- 				<li class="nav-item active">
					<strong><a class="nav-link a_Bums" href="" id="login_us"><i class="fa fa-user-circle-o" aria-hidden="true"></i> LOGIN</a></strong>
				</li> --}}
				<li>
					<button class="btn botonCarrito"
					data-toggle="modal" 
					data-target="#exampleModalLong"><i class="fa fa-shopping-cart fa-lg" aria-hidden="true"></i> <span class="badge badge-light rojoBlanco" id="badge">{{ count(Session::get('carrito')) }}</span></button>
				</li>
			</ul>		
		</div>
	</nav>
	<ul class="nav justify-content-center ulBums1 navNormal	" >
		<li class="nav-item">
			<a class="nav-link" href="{{ url('categorias') }}">Todas las categorias</a>
		</li>
		<form id="category_Playstation3_form" action="categoria_general" method="post">	
			{{ csrf_field() }}
			<input name='categoria' value="PlayStation 3" hidden="">		
			<li name="category" class="nav-item">
				<a class="nav-link active" href="#" onclick="document.getElementById('category_Playstation3_form').submit();">PlayStation 3</a>
			</li>
		</form>
		<form id="category_Playstation4_form" action="categoria_general" method="post">	
			{{ csrf_field() }}
			<input name='categoria' value="PlayStation 4" hidden="">		
			<li name="category" class="nav-item">
				<a class="nav-link active" href="#" onclick="document.getElementById('category_Playstation4_form').submit();">PlayStation 4</a>
			</li>
		</form>
		<li class="nav-item">
			<a class="nav-link" href="lista_escrita">Lista escrita</a>
		</li>
		<li class="nav-item marcaOferta">
			<a class="nav-link letraBlanca" href="/articulos_oferta">Ofertas</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="/articulos_web">Todos los articulos</a>
		</li>
		<li>
			<form class="form-inline" action="{{ url('prueba') }}" method="post">
				{{-- onchange="cambiaBandera(this.options[this.selectedIndex].value)" --}}
				<input name="_token" id="token" value="{{ csrf_token() }}" hidden="">
				<select class="form-control selectCoin" onchange="this.form.submit()" name="id_coin" id="id_coin">
					<option class="form-control" selected="" value="{{ $moneda_actual->id }}">{{ $moneda_actual->coin }}</option>
					@foreach($coins as $coin)
					<option class="form-control" value="{{ $coin->id }}">{{ $coin->coin }}</option>
					@endforeach
				</select>
				<img id="my_image" src="{{  url('img/'.$moneda_actual->imagen) }}" alt="" width="60">
			</form>
		</li>
	</ul>
	<div class="social-bar">
		<a href="https://www.instagram.com/bumsgames/" class="icon icon-facebook" target="_blank"></a>
		<a href="https://www.instagram.com/bumsgames/" class="icon icon-instagram" target="_blank"></a>
		<a href="https://www.instagram.com/bumsgames/" class="icon icon-youtube" target="_blank"></a>
		<a href="#" class="icon icon-instagram" target="_blank" hidden=""></a>
	</div>

	@yield('content')


	@include('modal.carrito')
	
	<br>	
	<br>	
	<br>	
	<br>	




	<footer class="page-footer font-small cyan darken-3 foot1">
		<div class="container">
			<br>
			<br>
			<div class="row">
				<a href="/pagina">

					<div class="col">

						<img alt="Brand" src="{{ url('img/logobums2.png') }}" width="175">
					</div>
				</a>
				<div class="col">
					Redes Sociales
					<hr>	
					<center>
						<a class="fb-ic" href="https://www.instagram.com/bumsgames/" target="_blank">
							<i class="fa fa-facebook fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
						</a>
						<a class="gplus-ic" href="https://www.instagram.com/bumsgames/" target="_blank"> 
							<i class="fa fa-google-plus fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
						</a>
						<!--Instagram-->
						<a class="ins-ic" href="https://www.instagram.com/bumsgames/" target="_blank">
							<i class="fa fa-instagram fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
						</a>
					</center>	
				</div>
				<div class="col">Contacto
					<hr>
					<div class="row">	
						<div class="col">
							David Salazar.
							<br>	
							<i class="fab fa-whatsapp fa-2x"></i> 
							(+58) 0414-867-32-99

							<br>
							<br>			
							Genesis Moreno.
							<br>	
							<i class="fab fa-whatsapp fa-2x"></i> 
							(+58) 0412-192-70-74
							<br>	
							<br>	
							Daniel Duarte.
							<br>	
							<i class="fab fa-whatsapp fa-2x"></i> 
							(+58) 0412-119-23-79
							<br>	
							<br>

						</div>
						<div class="col">	
							Yohan Franco (Brasil).
							<br>
							<i class="fab fa-whatsapp fa-2x"></i> 
							(+58) 414-772-74-21
							<br>	
							<br>
							Nestor Rojas (Argentina).
							<br>
							<i class="fab fa-whatsapp fa-2x"></i> 
							(+54) 9 11-3359-36-81

							<br>
							<br>
						</div>
					</div>

					
					
				</div>
			</div>
		</div>

		<div class="footer-copyright text-center py-3 foot2">Llegamos para hacer la diferencia.
			<a href="https://mdbootstrap.com/bootstrap-tutorial/"> BumsGames.com.ve</a>
		</div>
	</footer>

	{{-- ESENCIAL --}}
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	{{-- ESENCIAL --}}
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
	{{-- ESENCIAL --}}
	<script
	src="https://code.jquery.com/jquery-3.3.1.js"
	integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
	crossorigin="anonymous"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="{{ url('js/bums.js') }}"></script>

	<!-- Footer -->

</body>






</html>