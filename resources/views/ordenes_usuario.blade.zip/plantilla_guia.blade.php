<div class="tile-body" style="overflow-wrap: break-word;">
	<div class="row">
		<div class="col-3">
			<div class="list-group" id="list-tab" role="tablist">
				<a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Como registrar un articulo?</a>
				<a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">
					Como realizar una venta?
				</a>
				<a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">Tutoriales de descarga</a>
				<a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings"></a>
			</div>
		</div>
		<div class="col">
			<div class="tab-content letraNegra" id="nav-tabContent">
				<div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">
					<h4>Como registrar un articulo en BumsGames?</h4>
					<br>	
					1. El duenno es obligatorio.<br>
					<br>
					2. Cada articulo debe tener minimo un duenno y el porcentaje significa en que porcion la persona es duenno de ese articulo, ejemplo: Si hay un duenno con una accion de 50% en caso de venta, si se vende en 10 $ un articulo, esa persona se llevaria un 5$.
					<br>
					<br>

					3. La descripcion no es obligatoria por los momentos. <br>
					<br>
					4. Recuerden colocar la categoria correcta, ya que cada articulo registrado aparecera en la Pagina Web. <br>
					<br>
					5. Si un articulo se le marca "Si" en la parte de oferta en la Pagina Web saldra en oferta. <br>
					<br>
					6. El precio del articulo es en $ y la forma de calcularlo, lo marca el duenno del articulo, si no se sabe el precio del articulo en $, colocarlo en 0.
					<br>
					<br>
					7. Correo, Password, nicname y boton reseteo, solo se marca si es un Articulo digital de tipo Cuenta, el boton de reseteo solo aplica para Ps3 Cuenta Digital, Ps4 Primario y Secundario. Si no se sabe la fecha de reseteo, no rellenarlo.
					<br>
					<br>
					8. Cada articulo tiene una parte nota en caso de querer avisar algo, no es necesario rellenarlo.
					<br>
					<br>
					9. La foto de portada y foto de fondo son las fotos del articulo, ese disenno se puede apreciar mejor en la parte Web, cual foto es de cada cosa. Al no rellenarlo se le colocaran unas imagenes predeterminadas por el sistema.
					<br>
					<br>
					<br>
					Cualquier duda generar un Reporte, en el modulo reporte.
					<br>
					Recuerde que cada articulo registrado y que la cantidad sea mayor a 1, sera publicado en la Pagina Web.

				</div>
				<div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
					<strong>Como realizar una venta?</strong>
					<br>
					<br>
					1. Darle click en vender.
					<br>
					<br>
					2. Colocar el nombre, apellido y datos del cliente si es su primera venta. Si no es su primera venta al comenzar a escribir en los campos de texto de
					nombre y apellido, le saldran las coincidencias de la base de datos, al reconocer al cliente existente, darle click en Seleccionar.
					<br>
					<br>
					3. Colocar la cantidad vendida de ese articulo.
					<br>
					<br>
					4. La entidad significa el Banco Emisor desde donde se realiza el pago.
					<br>
					<br>
					5. La referencia es opcional
					<br>
					<br>
					6. Colocar el monto pagado y en que moneda se realizo el pago, si la moneda no existe, generar un reporte para que coloquen la nueva moneda.
					<br>
					<br>
					7. Las notas son opcionales
					<br>
					<br>
					8. Si el articulo se debe enviar clickear en la pantalla "Incluye envio." y rellenar los datos.
					<br>
					<br>
					9. Clickear en "Realizar Venta" y entregar el articulo o pautar la entrega. Recuerde colocar los datos correctos cuando termine en caso de ser cuenta digital.
					<br><br>
					Usted puede ver sus movimientos desde la seccion de Ventas o desde la Seccion Movimientos.
					<br>
					<br>
					Cualquier duda generar un reporte.


				</div>
				<div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
					<h2>Tutoriales de descarga</h2>
					<h4>PlayStation 4 Primario</h4>
					Crear usuario 》ingresar correo y clave que le daré 》omitir todo 》ir  biblioteca 》comprado

					INSTRUCCIONES: 
					VIDEOTUTORIAL: https://www.youtube.com/watch?v=fzHBj8vPZ3s&t=36s

					USUARIO PRINCIPAL IMPORTANTE

					1.-El juego tendra garantía en todo momento. Cualquier inconveniente avisenos para solventarle lo antes posible

					2.-No debe modificar la cuenta ni correo ni clave

					3.-No debe jugar con el usuario que le di dado que usted es usuario principal por ende debe jugar con su usuario personal u otro
					<br>	
					<br>	
					<br>	
					<h4>Pasos para descargar en PS4 SECUNDARIO</h4>

					Crear usuario 》iniciar sesion (ingresar correo y clave que le daré) 》¿Cambiar a esta PS4 principal? NO CAMBIAR 》ir  biblioteca 》comprado
					<br>	
					<br>	

					Tutorial: https://www.youtube.com/watch?v=5vXs4Gnxxi0
					<br>	

					USUARIO SECUNDARIO IMPORTANTE

					1.-El juego tendra garantía en todo momento. Cualquier inconveniente avisenos para solventarle lo antes posible
					<br>	

					2.-No debe modificar la cuenta ni correo ni clave
					<br>

					3.-Debe jugar con el usuario que le di dado que usted es usuario secundario
					<br>
					4.-No debe ponerse como usuario principal
					<br>
					5.-Para jugar debera tener OBLIGATORIAMENTE conexion a internet en su ps4

					la falta de alguno de estos items acarrea la perdida del juego

					¿COMO JUGAR UN JUEGO SECUNDARIO CON NUESTRO USUARIO PERSONAL? (solo aplica para algunos juegos)
					<br>
					Debe abrir el juego con el usuario que descargó (el que le dimos) > inmediatamente despues de iniciado debe cambiar a su usuario personal para el comienzo del juego
					<br>
					https://www.youtube.com/watch?v=X0Ha1McuIto
				</div>
				<div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">sdffsdfdsfds</div>
			</div>
		</div>
	</div>
	<br>
	<br>

	<hr>
	<div class="row">
		<div class="col">
			<strong>LINKS IMPORTANTES</strong>
			<br>
			<br>

			Chat PlayStation Sony: https://scea.secure.force.com/PreChatEnglishForm/?endpoint=https%3A%2F%2Fscea.secure.force.com%2FLiveChat%2Fapex%2FLiveAgentChat%3Flanguage%3D%23deployment_id%3D572i00000002cba%26org_id%3D00Di0000000H5ef%26button_id%3D573i00000002ftp%26session_id%3D0f4b4af2-9d70-46f1-8ed3-f8a5c264d39a 
			<br>
			<br>
			<br>
			<br>

			Migrar Cuenta Microsoft: https://live.xbox.com/en-US/AccountMigration 
			<br>
			<br>
			<br>
			<br>

			Plus 2 dias: https://www.youtube.com/watch?v=cPvmVizrlNU 
			<br>
			<br>
			<br>
			<br>


			Login Sony: https://id.sonyentertainmentnetwork.com/signin/?client_id=55950157-ae9d-4b10-b0de-94dbef199f2c&scope=openid%2Ckamaji%3Aprivacy_control%2Ckamaji%3Aactivity_feed_get_feed_privacy%2Ckamaji%3Aactivity_feed_set_feed_privacy&state=eyJ0aGVtZSI6ImxpcXVpZCJ9&redirect_uri=https%3A%2F%2Faccount.sonyentertainmentnetwork.com%2Foauth_security_check&response_type=code&prompt=login&ui=pr&noEVBlock=false&error=login_required&error_code=4165&error_description=User+is+not+authenticated#/signin?entry=%2Fsignin
		</div>
	</div>
</div>