@extends('layouts.admin-layout')
	@section('content')
	<div class="container">
		<center>
			<br>
			<h1>Menu Principal</h1>
		</center>
	</div>
	@endsection
