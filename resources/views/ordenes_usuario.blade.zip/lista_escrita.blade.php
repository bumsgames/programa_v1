@extends('layouts.plantillaWeb')

@section('content')
<br>
<br>
<style>
.btn-categorias{
	margin: 20px;
	padding: 10px !important;
}
.fondoBlanco{
	color: black !important;
	background: white !important;
}

.hr_negro{
    border: 1px black solid;
}
</style>
<div class="container">
	<div class="tile fondoBlanco">
		<h2>Lista escrita</h2>
		<hr class="hr_negro">
		<h5>
			Articulos disponibles: {{ $articulos->count() }}
		</h5>

		<form class="form-inline" action="lista_escrita" method="post">
			<input name="_token" id="token" value="{{ csrf_token() }}" hidden="">
			<select class="form-control" onchange="this.form.submit()" name="filtro" style="font-size: 14px;">
				<option class="form-control" value="">Sin filtro de busqueda</option>
				<option value="1">Menor a mayor</option>
				<option value="2">Mayor a menor</option>
				<option value="4">Orden alfabetico ascendente</option>
				<option value="3">Orden alfabetico descendente</option>
			</select>
		</form> 		
		<br>
		<?php $i = 1; ?>
		<?php $categoria = ''; ?>
		<div class="row">
			<div class="col">
				@foreach($articulos as $articulo)
				@if($articulo->pertenece_category->category != $categoria)
				<?php $categoria = $articulo->pertenece_category->category; ?>
				<?php $i = 1; ?>
				<h6>
					<br>
					<br>
					{{ $categoria }}
					<br>
					<br>
				</h6>
				@endif
				<p><?php echo $i++; ?>. {{$articulo->name }}, 
					<strong>{{ number_format($articulo->price_in_dolar * $moneda_actual->valor, 0, ',', '.') }} {{ $moneda_actual->sign }}

					</strong>
				</p>. 
				
				@endforeach
			</div>
			<div class="col-4">
				
				
			</div>
			
		</div>
		<br>
		<br>
		<br>
		<br>
	</div>

</div>


@endsection