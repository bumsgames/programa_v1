@extends('layouts.plantillaWeb')

@section('content')
<br>
<br>
<style>
.btn-categorias{
	margin: 20px;
	padding: 10px !important;
}
.fondoBlanco{
	color: black !important;
	background: white !important;
}
</style>
<div class="container">
	<div class="tile fondoBlanco">
		<h2>Ayuda</h2>
		<hr class="hr_negro">
		
		<br>
		<style>	
.list-group .active{
	background: #ff0005;
	border: none !important;
	opacity: 0.8 !important;
}

.hr_negro{
    border: 1px black solid;
}
	</style>
		<div class="row">
			<div class="col">
				<div class="row">
					<div class="col-4">
						<div class="list-group" id="list-tab" role="tablist">
							<a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Home</a>
							<a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">Profile</a>
							<a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">Messages</a>
							<a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings">Settings</a>
						</div>
					</div>
					<div class="col-8">
						<div class="tab-content letraNegra" id="nav-tabContent">
							<div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">fdssdfkjfdskjdfsm</div>
							<div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">fsdfsddffds</div>
							<div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">dfsfdsfsd</div>
							<div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">sdffsdfdsfds</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-2">
				
				
			</div>
			
		</div>
		<br>
		<br>
		<br>
		<br>
	</div>

</div>


@endsection