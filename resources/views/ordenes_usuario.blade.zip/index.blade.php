@extends('layouts.plantillaWeb')

@section('content')
<br>
<br>
<div class="container">
	<div class="tile">
		<h2>Bienvenido amig@</h2>
		<hr>
		<div class="row">
			<div class="col-8">
				<div class="container">

					<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="carousel-item active">
								<img class="d-block w-100" src="img/mario kart 8.jpg" alt="First slide">
								<div class="carousel-caption d-none d-md-block">
								</div>
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/gears.jpg">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/fifa19.jpg" alt="Third slide">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-4">
				<div class="container">
					<h4>Opciones</h4>
					<hr style="background: white;">
					<button class="btn btn-block btn-sm" onclick="location.href = 'categorias';">Categorias</button>
					<button class="btn btn-block btn-sm" onclick="location.href = 'https://perfil.mercadolibre.com.ve/BUMSPLAYERS';">Revisa nuestra reputacion.</button>
					<br>



					<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="carousel-item active">
								<img class="d-block w-100" src="img/mario kart 8.jpg" alt="First slide">
								<div class="carousel-caption d-none d-md-block">
								</div>
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/gears.jpg">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/fifa19.jpg" alt="Third slide">
							</div>
						</div>
					</div>
					<br>
					<button class="btn btn-block" onclick="location.href = 'ayuda';">Como comprar con BumsGames?</button>
				</div>

			</div>
		</div>
		<hr>
		<div class="row">

			<div class="col">
				<h3>Ultimos articulos</h3>
				<hr>
				<div class="padre">
					@foreach($articulos as $articulo)
					@include('carta')
					@endforeach
				</div>



			</div>
			<div class="col-3">
				<div class="container">
					<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="carousel-item active">
								<img class="d-block w-100" src="img/mario kart 8.jpg" height="400" alt="First slide">
								<div class="carousel-caption d-none d-md-block">
								</div>
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/gears.jpg" height="400">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/fifa19.jpg" height="400" alt="Third slide">
							</div>
						</div>
					</div>

				</div>
				<br>
				<br>		
				<style>
				.top{
					border: solid white 5px;
				}
			</style>
			<div class="container top">	
				<br>
				<strong>	Articulos mas vendidos de la semana
				</strong>
				<hr style="background-color: white !important; border: 1px solid;">
				<?php $i=1; ?>
				@foreach($articulo_mas_vendido_semana as $articulo)	
				<?php echo $i++; ?>. {{ $articulo->name }} | {{ $articulo->category }}
				<br>
				<br>

				@endforeach
				<br>		
			</div>

		</div>

	</div>
</div>

</div>


@endsection