@extends('layouts.bums')

@section('content')
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.0-alpha14/js/tempusdominus-bootstrap-4.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.0-alpha14/css/tempusdominus-bootstrap-4.min.css" />
</head>


<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> {{ $title }}</h1>
			<p>Llegamos para hacer la diferencia.</p>
		</div>
		<ul class="app-breadcrumb breadcrumb">
			<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
			<li class="breadcrumb-item"><a href="#">{{ $title }}</a></li>
		</ul>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<input type="text" id="movement" value="{{ $movement }}" hidden="">
				<button type="button" class="btn btn-success" onclick="window.location.href='{{ $url }}'">Movimientos tipo Banco</button>
				<button type="button"
				class="btn btn-success"
				data-toggle="modal" 
				data-target=".registrar_movimiento"
				id="prueba" 
				>Crear nuevo movimiento</button>
				@include('modal.registrar_movimiento')
				<br>
				<br>

				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Informacion</th>
								<th scope="col">Transaccion</th>
								<th scope="col">Articulo</th>
								<th scope="col">Fecha</th>

							</tr>
						</thead>
						<tbody>
							<?php $i = 1; ?>
							@foreach($movimientos as $movimiento)
							@if($movimiento->type == $movement)
							<tr>
								<td>
									<?php echo $i; $i++; ?>
								</td>
								<td>
									<strong>
										Entidad:
									</strong>
									{{ $movimiento->entidad }}
									<br>
									<br>

									<strong>
										Descripcion:
									</strong>
									{{ $movimiento->description }}
									<br>


								</td>
								<td>

									@foreach( $movimiento->usuario as $x)
									@if( $x->pivot->porcentaje == 0)
									Comision
									{{ $x->name }} {{ $x->lastname }}

									@if($movimiento->comision)
									<br>
									{{ $movimiento->comision }} {{ $movimiento->moneda->sign }}
									@else
									<br>
									<br>
									FALTA COLOCARLE LA COMISION POR VENDER
									@endif
									<br>	
									<br>	

									@else
									Duenno: ({{ $x->name }} {{ $x->lastname }})
									<br>	
									{{ number_format((($x->pivot->porcentaje / 100) *  $movimiento->price) - ($movimiento->comision * ($x->pivot->porcentaje / 100) ), 0, ',', '.')}} {{ $movimiento->moneda->sign }}  ({{ $x->pivot->porcentaje }} %)
									<br>	
									@if($x->pivot->permiso == 1)
									<br>
									@if(starts_with($movimiento->description, 'Venta Realizada'))	
									Este usuario modifica la comision
									@if($x->id == Auth::id() || auth()->user()->level >= 10)

									<form action="guardar_comision" method="POST">
										{{ csrf_field() }}
										<input type="text" name="id_movimiento" value="{{ $movimiento->id }}" hidden="">
										<input type="text" name="comision" autocomplete="off">
										<button>Generar comision</button>
									</form>
									@endif
									<br>
									<br>
									@endif
									@endif
									<br>	
									@endif

									@endforeach


									<strong>
										Total: 
									</strong>
									{{ number_format($movimiento->price, 0, ',', '.') }}
									{{ $movimiento->moneda->sign }}
								</td>
								<td>

									@if(starts_with($movimiento->description, 'Venta Realizada'))
									
									@foreach( $movimiento->venta as $movimiento->venta)
									<strong>Articulo: </strong><br>
									
									{{ $movimiento->venta->articulo->name }} 
									<br>
									<br>
									<strong>Articulo: </strong><br>	 Categoria: {{ $movimiento->venta->articulo->pertenece_category->category }}
									<br>
									<br>

									{{ $movimiento->venta->articulo->email }} | {{ $movimiento->venta->articulo->password }} | {{ $movimiento->venta->articulo->password }}
									<br>
									<br>
									<br>
									<strong>Cliente: </strong><br>	
									{{ $movimiento->venta->cliente->name }} || {{ $movimiento->venta->cliente->lastname }}
									@break

									@endforeach

									@else
									NO APLICA

									@endif
								</td>
								<td>
									<strong>	
										Fecha:
									</strong>
									{{ $movimiento->updated_at}}
									{{-- {{ $movimiento->updated_at->format("Y-m-d")}} --}}
									<br>
									<br>
									{{ $movimiento->updated_at }}
								</td>
								<td>
									<div class="btn-group" role="group" aria-label="Basic example">
										<button type="button" 
										class="btn btn-secondary" 
										data-toggle="modal" data-target=".bd-example-modal-lg3" Onclick="mandaridM({{$movimiento->id}} );">Eliminar</button>
									</div>
								</td>

							</tr>

							@endif
							@endforeach


						</tbody>

					</table>
				</div>


			</div>

		</div>
	</div>
	<div class="modal fade bd-example-modal-lg3" tabindex="-1" role="dialog" aria-labelledby="myLargeModal" aria-hidden="true">
		<div class="modal-dialog modal-lg3">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Debe ingresar la clave autorizada para eliminar</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="row">
				</div>
				<div class="container">

					<form action="">
						<input name="_token" id="token" value="{{ csrf_token() }}" hidden="">
						<input readonly="" id="id_eliminar" value="" type="text" hidden="">

						<div class="form-group">
							<label for="">CLAVE</label>
							<input type="password" name="clave" id="clave" class="form-control">
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							<button type="button" class="btn btn-primary" id="" value=" " Onclick='Eliminar_mov2();'>Eliminar</button>
						</div>
					</form>
				</div>

			</div>
		</div>
	</div>

	<div class="modal fade bd-example-modal-lg3" tabindex="-1" role="dialog" aria-labelledby="myLargeModal" aria-hidden="true">
		<div class="modal-dialog modal-lg3">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Debe ingresar la clave autorizada para eliminar</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="row">
				</div>
				<div class="container">

					<form action="">
						<input name="_token" id="token" value="{{ csrf_token() }}" hidden="">
						<input readonly="" id="id_eliminar" value="" type="text" hidden="">

						<div class="form-group">
							<label for="">CLAVE</label>
							<input type="password" name="clave" id="clave" class="form-control">
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							<button type="button" class="btn btn-primary" id="" value=" " Onclick='Eliminar_mov();'>Eliminar</button>
						</div>
					</form>
				</div>

			</div>
		</div>
	</div>
</main>

@endsection