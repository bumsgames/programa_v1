@extends('layouts.bums')

@section('content')
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> Clientes </h1>
			<p>Aqui es donde comienza todo.</p>
		</div>		
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<input type="text" placeholder="Buscar" class="form-control" id="buscador">
				<br>
				<br>
				
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Nombre</th>
								<th scope="col">Nickname</th>
								<th scope="col">Numero Contacto</th>
								<th scope="col">Email</th>
								<th scope="col">Nota</th>
								<th scope="col">Foto</th>
							</tr>
						</thead>
						<tbody>
							<?php $i=1; ?>
							@foreach($clientes as $cliente)
							<tr>	
								<td><?php echo $i++; ?> </td>
								<td>	
									{{ $cliente->name }} {{ $cliente->lastname }}
								</td>
								<td>	
									{{ $cliente->nickname }}
								</td>
								<td>
									{{ $cliente->num_contact }}
								</td>
								<td>	
									{{ $cliente->email }}
								</td>
								<td>	
									{{ $cliente->email }}
								</td>
								<td>
									{{ $cliente->image }}	
								</td>
								<td>

									<div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
										<form action="ver_articulos" method="post">
											{{ csrf_field() }}
											<input type="text" name="id" hidden="" value="{{ $cliente->id }}">
											<button type="submit" class="btn btn-secondary">Compras</button>
										</form>
										<button type="button" class="btn btn-primary" data-toggle="modal" Onclick="mandaridM({{ $cliente->id }});" data-target=".eliminar_cliente">Eliminar cliente</button>
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</main>

<div class="modal fade eliminar_cliente" tabindex="-15" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<input name="_token" id="token" value="{{ csrf_token() }}" hidden="">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLongTitle">Eliminar cliente</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<label for="">CLIENTE A ELIMINAR</label>
				<input type="text" class="form-control" id="id_eliminar" readonly="">
				<br>
				<br>
				<label for="">CLAVE PARA ELIMINAR</label>
				<input type="password" class="form-control" id="password_eliminar">
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary" id="boton_eliminar_cliente">Eliminar cliente</button>
			</div>
		</div>
	</div>
</div>


@endsection