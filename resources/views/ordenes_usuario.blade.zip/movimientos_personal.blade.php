@extends('layouts.bums')

@section('content')
<main class="app-content">
	<div class="app-title">
		<div>
			<h1><i class="fa fa-dashboard"></i> {{ $title }}</h1>
			<p>Llegamos para hacer la diferencia.</p>
		</div>
		<ul class="app-breadcrumb breadcrumb">
			<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
			<li class="breadcrumb-item"><a href="#">{{ $title }}</a></li>
		</ul>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="tile">
				<input type="text" id="movement" value="{{ $movement }}" hidden="">
				<button type="button" class="btn btn-success" onclick="window.location.href='{{ $url }}'">Movimientos tipo Banco</button>
				<button type="button"
				class="btn btn-success"
				data-toggle="modal" 
				data-target=".registrar_movimiento"
				id="prueba" 
				>Crear Nuevo movimiento</button>
				@include('modal.registrar_movimiento')
				<br>
				<br>
				<input type="text" placeholder="Buscar" class="form-control" id="buscador">
				<br>
				<br>
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">#</th>
								<th scope="col">Informacion</th>
								<th scope="col">Transaccion</th>
								<th scope="col">Articulo</th>
								<th scope="col">Fecha</th>
								
							</tr>
						</thead>
						<tbody>
							<?php $i = 1; ?>
							@foreach($movimientos as $movimiento)
							<tr>
								<td>
									<?php echo $i; $i++; ?>
								</td>
								<td>	
									<strong>Entidad: </strong>
									{{ $movimiento->movimiento->entidad }}
									<br>
									<br>
									<strong>Descripcion:</strong>
									@if($movimiento->descripcion_movimiento)

									{{ $movimiento->descripcion_movimiento }}	
									@else
									{{ $movimiento->movimiento->description }}
									@endif
									
									<br>
									<br>
									@if(isset($movimiento->venta->user->name))
									Vendedor: {{ $movimiento->venta->user->name }} {{ $movimiento->venta->user->lastname }}

									@endif

									<br>
									<br>
									<strong>Nota: </strong>{{ $movimiento->note_movimiento }}
									

									
								</td>
								<td>	
									
									Persona: {{ Auth::user()->name }} {{ Auth::user()->lastname }}
									<br>	
									<br>
									@if($movimiento->porcentaje != 0)
									Acciones: {{ $movimiento->porcentaje }} %
									<br>	
									<br>	
									Total: {{ number_format($movimiento->movimiento->price * ($movimiento->porcentaje / 100), 0, ',', '.') }} 
									{{  $movimiento->movimiento->moneda->sign }}
									@else
									VENTA REALIZADA
									<br>	
									<br>	
									LE DEBEN COLOCAR LA COMISION
									{{ $movimiento->comision }}
									@endif
									
									

								</td>
								<td>

									@if(isset($movimiento->venta->articulo))

									{{ $movimiento->venta->articulo->name }}
									<br>	
									
									<br>	
									<br>	
									Categoria: {{ $movimiento->venta->articulo->pertenece_category->category }}
									<br>	
									<br>	
									{{ $movimiento->venta->articulo->email }}
									<br>
									{{ $movimiento->venta->articulo->password }}
									<br>
									{{ $movimiento->venta->articulo->nickname }}

									{{-- {{ $movimiento->venta->articulo }} --}}
									@else
									NO APLICA
									@endif

								</td>
								<td>
									{{-- {{ $movimiento->movimiento->updated_at		 }}	 --}}
									<strong>	
										{{ $movimiento->movimiento->updated_at->format('d M Y ')}}
									</strong>
									{{-- {{ $movimiento->updated_at->format("Y-m-d")}} --}}
									<br>
									<br>
									{{ $movimiento->movimiento->updated_at->diffForHumans() }}
								</td>
								<td>
									<button class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg3" Onclick="mandaridM({{$movimiento->id}} );" >Eliminar movimiento</button>
								</td>
								

								@endforeach
							</tbody>

						</table>
					</div>


				</div>

			</div>
		</div>
		<div class="modal fade bd-example-modal-lg3" tabindex="-1" role="dialog" aria-labelledby="myLargeModal" aria-hidden="true">
			<div class="modal-dialog modal-lg3">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Debe ingresar la clave autorizada para eliminar</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="row">
					</div>
					<div class="container">

						<form action="">
							<input name="_token" id="token" value="{{ csrf_token() }}" hidden="">
							<input readonly="" id="id_eliminar" value="" type="text" hidden="">

							<div class="form-group">
								<label for="">CLAVE</label>
								<input type="password" name="clave" id="clave" class="form-control">
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								<button type="button" class="btn btn-primary" id="" value=" " Onclick='Eliminar_mov2();'>Eliminar</button>
							</div>
						</form>
					</div>

				</div>
			</div>
		</div>


	</main>

	@include('modal.modificar_movimiento')


	@endsection